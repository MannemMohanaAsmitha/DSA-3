import { useState } from 'react';
import { Header, ActiveTab } from './components/Header.tsx';
import { HeroBanner } from './components/HeroBanner.tsx';
import { QueryEngineDemo } from './components/QueryEngineDemo.tsx';
import { ExactVsFuzzyComparison } from './components/ExactVsFuzzyComparison.tsx';
import { DPMatrixExplorer } from './components/DPMatrixExplorer.tsx';
import { BenchmarkDashboard } from './components/BenchmarkDashboard.tsx';
import { PresentationSlidesView } from './components/PresentationSlidesView.tsx';
import { CorpusExplorer } from './components/CorpusExplorer.tsx';
import { TeamSection } from './components/TeamSection.tsx';
import { Footer } from './components/Footer.tsx';
import { PatientDirectoryView } from './components/PatientDirectoryView.tsx';
import { getStoredPatients, savePatients, resetToSeedPatients } from './data/patientDataset.ts';
import { Patient } from './types/index.ts';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('patients');
  const [currentQuery, setCurrentQuery] = useState<string>('paracetmol');
  const [dpPair, setDpPair] = useState<{ s1: string; s2: string }>({
    s1: 'dibetes',
    s2: 'diabetes',
  });

  // 1,000 Patient Records State
  const [patients, setPatients] = useState<Patient[]>(() => getStoredPatients());

  const handleAddPatient = (newPatient: Patient) => {
    const updated = [newPatient, ...patients];
    setPatients(updated);
    savePatients(updated);
  };

  const handleResetPatients = () => {
    const seed = resetToSeedPatients();
    setPatients(seed);
  };

  const handleSelectQueryFromHero = (typo: string) => {
    setCurrentQuery(typo);
    setActiveTab('search');
    const el = document.getElementById('live-query-engine-container');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleInspectDP = (s1: string, s2: string) => {
    setDpPair({ s1, s2 });
    setActiveTab('dp-matrix');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleTestTermFromCorpus = (term: string) => {
    setCurrentQuery(term);
    setActiveTab('search');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleTabChange = (tab: ActiveTab) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Academic Navigation Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        patientCount={patients.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8 space-y-10">
        {/* Hero Pipeline Banner (Only on search tab to avoid obstructing patient dataset) */}
        {activeTab === 'search' && (
          <HeroBanner
            onSelectQuery={handleSelectQueryFromHero}
            onExploreDP={(s1, s2) => handleInspectDP(s1, s2)}
            onNavigatePatients={() => handleTabChange('patients')}
          />
        )}

        {/* Tab 0: 1,000 Patient Records Dataset & DSA Retrieval */}
        {activeTab === 'patients' && (
          <PatientDirectoryView
            patients={patients}
            onAddPatient={handleAddPatient}
            onResetPatients={handleResetPatients}
            onInspectDP={handleInspectDP}
          />
        )}

        {/* Tab 1: Live Medical Term Query Engine */}
        {activeTab === 'search' && (
          <QueryEngineDemo
            currentQuery={currentQuery}
            setCurrentQuery={setCurrentQuery}
            onInspectDP={handleInspectDP}
          />
        )}

        {/* Tab 2: Exact vs. Fuzzy Comparison */}
        {activeTab === 'comparison' && <ExactVsFuzzyComparison />}

        {/* Tab 3: Dynamic Programming Matrix Explorer */}
        {activeTab === 'dp-matrix' && (
          <DPMatrixExplorer initialS1={dpPair.s1} initialS2={dpPair.s2} />
        )}

        {/* Tab 4: Benchmark & Empirical Evaluation (96% vs 58%) */}
        {activeTab === 'benchmark' && <BenchmarkDashboard />}

        {/* Tab 5: Slide Deck View (Slides 1-7) */}
        {activeTab === 'presentation' && <PresentationSlidesView />}

        {/* Tab 6: Structured Medical Corpus */}
        {activeTab === 'corpus' && (
          <CorpusExplorer onTestTerm={handleTestTermFromCorpus} />
        )}

        {/* Tab 7: Team Members & Academic Roles */}
        {activeTab === 'team' && <TeamSection />}
      </main>

      {/* Academic Footer */}
      <Footer />
    </div>
  );
}
