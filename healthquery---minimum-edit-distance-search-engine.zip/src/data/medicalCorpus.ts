import { MedicalEntry, BenchmarkTestCase, TeamMember } from '../types/index.ts';

export const TEAM_MEMBERS: TeamMember[] = [
  {
    name: 'M. Mohana Asmitha',
    rollNo: '2520030486',
    initials: 'MA',
    role: 'Algorithm Design & Evaluation',
    department: 'Department of Computer Science'
  },
  {
    name: 'G. Laasya',
    rollNo: '2520030118',
    initials: 'GL',
    role: 'Dictionary Engine & Retrieval System',
    department: 'Department of Computer Science'
  },
  {
    name: 'Ch. Nohitha',
    rollNo: '2520030130',
    initials: 'CN',
    role: 'Corpus Architecture & Data Structures',
    department: 'Department of Computer Science'
  },
  {
    name: 'K. Dheeraj',
    rollNo: '2520030193',
    initials: 'KD',
    role: 'UI/UX Interface & JUnit Testing',
    department: 'Department of Computer Science'
  }
];

export const MEDICAL_CORPUS: MedicalEntry[] = [
  // DRUGS
  {
    id: 'med-1',
    term: 'Paracetamol',
    category: 'drug',
    categoryLabel: 'Drug / Analgesic',
    definition: 'Common antipyretic and non-opioid analgesic used to treat mild to moderate pain and reduce fever.',
    indications: 'Fever, headache, toothache, musculoskeletal pain, post-immunization pyrexia.',
    clinicalNotes: 'Maximum adult dose is 4g in 24 hours. Hepatotoxicity risk with overdose.',
    commonMisspellings: ['paracetmol', 'paracetamal', 'paracitamol', 'paracitomol', 'paracetemol']
  },
  {
    id: 'med-2',
    term: 'Ibuprofen',
    category: 'drug',
    categoryLabel: 'Drug / NSAID',
    definition: 'Nonsteroidal anti-inflammatory drug (NSAID) inhibiting COX-1 and COX-2 enzymes.',
    indications: 'Arthritis, acute dysmenorrhea, migraine, inflammation, post-surgical pain.',
    clinicalNotes: 'Administer with food. Monitor for gastrointestinal ulceration and renal impairment.',
    commonMisspellings: ['ibuprofn', 'ibruprofen', 'ibuprophen', 'ibuprfen', 'ibrupofen']
  },
  {
    id: 'med-3',
    term: 'Amoxicillin',
    category: 'drug',
    categoryLabel: 'Drug / Antibiotic',
    definition: 'Broad-spectrum beta-lactam penicillin-class antibiotic active against gram-positive and gram-negative bacteria.',
    indications: 'Streptococcal pharyngitis, acute otitis media, community-acquired pneumonia, skin infections.',
    clinicalNotes: 'Check for penicillin allergies. May cause mild diarrhea or hypersensitivity rash.',
    commonMisspellings: ['amoxiclin', 'amoxycillin', 'amoxicilin', 'amoxacillin', 'amoxacilin']
  },
  {
    id: 'med-4',
    term: 'Metformin',
    category: 'drug',
    categoryLabel: 'Drug / Biguanide',
    definition: 'First-line oral antidiabetic medication reducing hepatic glucose production and improving insulin sensitivity.',
    indications: 'Type 2 Diabetes Mellitus, gestational diabetes, polycystic ovary syndrome (PCOS).',
    clinicalNotes: 'Contraindicated in severe renal impairment (eGFR < 30 mL/min). Risk of lactic acidosis.',
    commonMisspellings: ['metformin', 'metforman', 'metformine', 'metaformin', 'metfromin']
  },
  {
    id: 'med-5',
    term: 'Atorvastatin',
    category: 'drug',
    categoryLabel: 'Drug / Statin',
    definition: 'HMG-CoA reductase inhibitor lowering low-density lipoprotein (LDL) cholesterol and triglycerides.',
    indications: 'Hypercholesterolemia, primary dyslipidemia, cardiovascular risk reduction.',
    clinicalNotes: 'Monitor liver function and assess for unexplained muscle pain (rhabdomyolysis risk).',
    commonMisspellings: ['atorvastin', 'atorvastatin', 'atorvastine', 'atarvastatin', 'atrvastatin']
  },
  {
    id: 'med-6',
    term: 'Omeprazole',
    category: 'drug',
    categoryLabel: 'Drug / PPI',
    definition: 'Proton pump inhibitor (PPI) suppressing gastric basal and stimulated acid secretion.',
    indications: 'Gastroesophageal reflux disease (GERD), peptic ulcer disease, Zollinger-Ellison syndrome.',
    clinicalNotes: 'Long-term usage associated with hypomagnesemia and bone fracture risks.',
    commonMisspellings: ['omeprazol', 'omeprazole', 'omiprazole', 'omaprazole', 'omeprazole']
  },
  {
    id: 'med-7',
    term: 'Azithromycin',
    category: 'drug',
    categoryLabel: 'Drug / Macrolide',
    definition: 'Macrolide antibiotic binding to the 50S ribosomal subunit, preventing bacterial protein synthesis.',
    indications: 'Respiratory tract infections, chlamydia, sinusitis, community-acquired pneumonia.',
    clinicalNotes: 'Known for short course (Z-Pak). Caution with patients having prolonged QT interval.',
    commonMisspellings: ['azithromicin', 'azithromycin', 'azithromycine', 'azithromisen', 'azathromycin']
  },
  {
    id: 'med-8',
    term: 'Ciprofloxacin',
    category: 'drug',
    categoryLabel: 'Drug / Fluoroquinolone',
    definition: 'Fluoroquinolone antibiotic that inhibits bacterial DNA gyrase and topoisomerase IV.',
    indications: 'Complicated urinary tract infections (UTIs), bacterial diarrhea, intra-abdominal infections.',
    clinicalNotes: 'Black box warning for tendon rupture and peripheral neuropathy.',
    commonMisspellings: ['ciprofloxacine', 'ciproflaxin', 'ciprofloxacin', 'ciproflaxacin', 'ciprofloxcin']
  },
  {
    id: 'med-9',
    term: 'Cetirizine',
    category: 'drug',
    categoryLabel: 'Drug / Antihistamine',
    definition: 'Second-generation selective histamine H1-receptor antagonist providing non-sedating relief.',
    indications: 'Allergic rhinitis, chronic urticaria, seasonal allergies, pruritus.',
    clinicalNotes: 'Less sedating than first-generation antihistamines, but may cause mild drowsiness in some.',
    commonMisspellings: ['cetirizne', 'cetrizine', 'ceterizine', 'citirizine', 'cetrizin']
  },
  {
    id: 'med-10',
    term: 'Losartan',
    category: 'drug',
    categoryLabel: 'Drug / ARB',
    definition: 'Angiotensin II receptor blocker (ARB) promoting vasodilation and reducing aldosterone excretion.',
    indications: 'Hypertension, diabetic nephropathy, stroke prophylaxis in hypertensive patients.',
    clinicalNotes: 'Monitor serum potassium levels; avoid during pregnancy due to fetal toxicity.',
    commonMisspellings: ['losartin', 'losartan', 'losartane', 'lozartan', 'lossartan']
  },
  {
    id: 'med-11',
    term: 'Levothyroxine',
    category: 'drug',
    categoryLabel: 'Drug / Thyroid Hormone',
    definition: 'Synthetic levo isomer of thyroid hormone (T4) replacing depleted endogenous hormone.',
    indications: 'Hypothyroidism, pituitary TSH suppression in thyroid cancer, euthyroid goiters.',
    clinicalNotes: 'Take on an empty stomach 30-60 minutes before breakfast with a full glass of water.',
    commonMisspellings: ['levothyroxin', 'levothiroxine', 'levothyroxne', 'levothyroxine', 'levothyroxin']
  },
  {
    id: 'med-12',
    term: 'Albuterol',
    category: 'drug',
    categoryLabel: 'Drug / Bronchodilator',
    definition: 'Short-acting selective beta-2 adrenergic agonist causing relaxation of bronchial smooth muscle.',
    indications: 'Acute bronchospasm in asthma, exercise-induced asthma, COPD exacerbation.',
    clinicalNotes: 'Rescue inhaler. Common side effects include tremors and tachycardia.',
    commonMisspellings: ['albutrol', 'albuterol', 'albterol', 'albutarol', 'albutral']
  },
  {
    id: 'med-13',
    term: 'Hydrochlorothiazide',
    category: 'drug',
    categoryLabel: 'Drug / Diuretic',
    definition: 'Thiazide diuretic that inhibits sodium-chloride cotransporter in the distal convoluted tubule.',
    indications: 'Essential hypertension, peripheral edema, congestive heart failure.',
    clinicalNotes: 'Check electrolytes regularly (risk of hypokalemia, hyponatremia, hyperuricemia).',
    commonMisspellings: ['hydrochlorothiazid', 'hydrochlorothiazide', 'hydrochlorothiazid', 'hydrochlorothiazde']
  },
  {
    id: 'med-14',
    term: 'Gabapentin',
    category: 'drug',
    categoryLabel: 'Drug / Anticonvulsant',
    definition: 'Structural analogue of GABA that modulates voltage-gated calcium channels.',
    indications: 'Neuropathic pain, post-herpetic neuralgia, focal seizure adjunct.',
    clinicalNotes: 'Dose must be tapered when discontinuing; causes sedation and dizziness.',
    commonMisspellings: ['gabapentin', 'gabapantin', 'gabapentine', 'gabapenten', 'gabbapentin']
  },
  {
    id: 'med-15',
    term: 'Cephalexin',
    category: 'drug',
    categoryLabel: 'Drug / Cephalosporin',
    definition: 'First-generation cephalosporin antibiotic inhibiting bacterial cell wall synthesis.',
    indications: 'Skin and soft tissue infections, osteomyelitis, respiratory tract infections.',
    clinicalNotes: 'Cross-allergy risk in patients with severe IgE-mediated penicillin allergies.',
    commonMisspellings: ['cephlaxin', 'cephalexine', 'cefalexin', 'cephilexin', 'cephalexan']
  },

  // SYMPTOMS
  {
    id: 'sym-1',
    term: 'Headache',
    category: 'symptom',
    categoryLabel: 'Symptom / Neurological',
    definition: 'Pain or aching sensation occurring in any region of the head or upper neck.',
    indications: 'Can indicate tension, migraine, cluster episodes, or acute intracranial pathology.',
    clinicalNotes: 'Evaluate "red flags" (thunderclap onset, systemic symptoms, papilledema).',
    commonMisspellings: ['headach', 'headache', 'hedache', 'head ache', 'hedach']
  },
  {
    id: 'sym-2',
    term: 'Dyspnea',
    category: 'symptom',
    categoryLabel: 'Symptom / Respiratory',
    definition: 'Subjective experience of breathing discomfort or shortness of breath of varying intensity.',
    indications: 'Cardiopulmonary disorders, asthma, congestive heart failure, pulmonary embolism, anemia.',
    clinicalNotes: 'Assess onset (acute vs chronic), orthopnea, and oxygen saturation immediately.',
    commonMisspellings: ['dyspnea', 'dispnea', 'dyspnoea', 'dyspnia', 'dyspnea']
  },
  {
    id: 'sym-3',
    term: 'Fatigue',
    category: 'symptom',
    categoryLabel: 'Symptom / Systemic',
    definition: 'Persistent feeling of tiredness, lack of physical energy, or mental exhaustion not relieved by rest.',
    indications: 'Hypothyroidism, chronic infection, anemia, sleep apnea, depressive disorders.',
    clinicalNotes: 'Differentiate physical muscle weakness from overall malaise and sleepiness.',
    commonMisspellings: ['fatige', 'fatigue', 'fatigiue', 'fatique', 'fatugue']
  },
  {
    id: 'sym-4',
    term: 'Arrhythmia',
    category: 'symptom',
    categoryLabel: 'Symptom / Cardiovascular',
    definition: 'Irregular rhythm or rate of heartbeat, perceived as fluttering, skipped beats, or palpitations.',
    indications: 'Atrial fibrillation, ventricular extrasystoles, electrolyte imbalance, anxiety.',
    clinicalNotes: 'Electrocardiogram (ECG) is required for definitive diagnostic rhythm classification.',
    commonMisspellings: ['arrythmia', 'arrhythmia', 'arythmia', 'arrhytmia', 'arhythmia']
  },
  {
    id: 'sym-5',
    term: 'Hypertension',
    category: 'symptom',
    categoryLabel: 'Symptom & Sign / Vascular',
    definition: 'Elevated arterial systemic blood pressure consistently measuring >= 130/80 mmHg.',
    indications: 'Primary cardiovascular dysfunction, chronic kidney disease, endocrine hyperactivity.',
    clinicalNotes: 'Often termed the "silent killer" because it remains asymptomatic for years.',
    commonMisspellings: ['hypertnnsion', 'hypertension', 'hypertention', 'hypertesion', 'hypertenshion']
  },
  {
    id: 'sym-6',
    term: 'Paresthesia',
    category: 'symptom',
    categoryLabel: 'Symptom / Neurological',
    definition: 'Abnormal sensation of the skin typically described as tingling, prickling, or numbness ("pins and needles").',
    indications: 'Peripheral neuropathy, vitamin B12 deficiency, nerve root impingement, multiple sclerosis.',
    clinicalNotes: 'Check dermatomal distribution to localize peripheral vs central lesions.',
    commonMisspellings: ['parethesia', 'paraesthesia', 'peresthesia', 'paresthsia', 'paresthesea']
  },
  {
    id: 'sym-7',
    term: 'Nausea',
    category: 'symptom',
    categoryLabel: 'Symptom / Gastrointestinal',
    definition: 'Unpleasant subjective feeling of impending emesis, localized to the epigastrium or throat.',
    indications: 'Gastroenteritis, drug toxicity, labyrinthitis, vestibular disturbance, pregnancy.',
    clinicalNotes: 'Often mediated by chemoreceptor trigger zone and vagal afferents.',
    commonMisspellings: ['nausia', 'naushea', 'nauzea', 'nausia', 'nasea']
  },
  {
    id: 'sym-8',
    term: 'Vertigo',
    category: 'symptom',
    categoryLabel: 'Symptom / Otoneurological',
    definition: 'Perceived hallucination of motion, where the patient or environment feels as if spinning.',
    indications: 'Benign paroxysmal positional vertigo (BPPV), vestibular neuritis, Meniere disease.',
    clinicalNotes: 'Perform Dix-Hallpike maneuver; distinguish true rotational vertigo from lightheadedness.',
    commonMisspellings: ['vertgo', 'vertygo', 'vertago', 'vertigo', 'virtego']
  },
  {
    id: 'sym-9',
    term: 'Tachycardia',
    category: 'symptom',
    categoryLabel: 'Symptom / Cardiovascular',
    definition: 'Resting heart rate exceeding 100 beats per minute in adult patients.',
    indications: 'Fever, hypovolemia, hyperthyroidism, pheochromocytoma, physical exertion.',
    clinicalNotes: 'Evaluate hemodynamics; distinguish sinus tachycardia from supraventricular tachycardia.',
    commonMisspellings: ['tachicardia', 'tackicardia', 'tachicardia', 'tachycarida', 'tachycardia']
  },
  {
    id: 'sym-10',
    term: 'Rhinorrhea',
    category: 'symptom',
    categoryLabel: 'Symptom / ENT',
    definition: 'Excessive thin and clear discharge of mucus from the nasal cavities (runny nose).',
    indications: 'Upper respiratory infection, allergic rhinitis, vasomotor rhinitis, CSF leak.',
    clinicalNotes: 'Unilateral clear post-traumatic drainage must be screened for beta-2 transferrin (CSF).',
    commonMisspellings: ['rhinorea', 'rhinorrhea', 'rinorrhea', 'rhinorroea', 'rhinnorea']
  },
  {
    id: 'sym-11',
    term: 'Myalgia',
    category: 'symptom',
    categoryLabel: 'Symptom / Musculoskeletal',
    definition: 'Generalized or localized muscular aches and soreness across skeletal muscle groups.',
    indications: 'Viral infections (influenza, dengue), fibromyalgia, strenuous exercise, statin myopathy.',
    clinicalNotes: 'Evaluate creatine kinase (CK) if severe muscle tenderness or dark urine is observed.',
    commonMisspellings: ['myalga', 'mialgia', 'myalgea', 'myalgia', 'mialga']
  },
  {
    id: 'sym-12',
    term: 'Arthralgia',
    category: 'symptom',
    categoryLabel: 'Symptom / Rheumatological',
    definition: 'Joint ache or pain affecting one or multiple joints without obvious physical joint swelling.',
    indications: 'Early osteoarthritis, rheumatoid arthritis, systemic lupus erythematosus (SLE).',
    clinicalNotes: 'Differentiate simple arthralgia from true inflammatory arthritis with joint effusion.',
    commonMisspellings: ['arthalgia', 'artralgia', 'arthralga', 'arthralgia', 'arthragia']
  },

  // DIAGNOSES & DISEASES
  {
    id: 'dx-1',
    term: 'Diabetes Mellitus',
    category: 'diagnosis',
    categoryLabel: 'Diagnosis / Endocrine',
    definition: 'Chronic metabolic disorder characterized by persistent hyperglycemia due to insulin defects.',
    indications: 'Polydipsia, polyuria, polyphagia, unexplained weight loss, elevated HbA1c >= 6.5%.',
    clinicalNotes: 'Complications include retinopathy, nephropathy, neuropathy, and macrovascular disease.',
    commonMisspellings: ['dibetes', 'diabtes mellitus', 'diabates', 'diabites', 'diabetis']
  },
  {
    id: 'dx-2',
    term: 'Bronchial Asthma',
    category: 'diagnosis',
    categoryLabel: 'Diagnosis / Pulmonology',
    definition: 'Chronic inflammatory airway disorder featuring reversible bronchial hyperresponsiveness.',
    indications: 'Recurrent wheezing, nighttime coughing, chest tightness, episodic shortness of breath.',
    clinicalNotes: 'Monitored with spirometry (FEV1/FVC ratio) and peak expiratory flow meters.',
    commonMisspellings: ['asthema', 'bronchial astma', 'bronchial asthma', 'astma', 'bronchial asma']
  },
  {
    id: 'dx-3',
    term: 'Atherosclerosis',
    category: 'diagnosis',
    categoryLabel: 'Diagnosis / Cardiovascular',
    definition: 'Pathological narrowing and stiffening of arteries caused by fibrofatty plaque accumulation.',
    indications: 'Angina pectoris, intermittent claudication, transient ischemic attacks, arterial bruits.',
    clinicalNotes: 'Major underlying cause of coronary artery disease, strokes, and peripheral arterial disease.',
    commonMisspellings: ['atheroclerosis', 'athrosclerosis', 'atherosclorosis', 'athersclerosis']
  },
  {
    id: 'dx-4',
    term: 'Pneumonia',
    category: 'diagnosis',
    categoryLabel: 'Diagnosis / Pulmonology',
    definition: 'Acute infection of the pulmonary parenchymal tissue producing alveolar consolidation.',
    indications: 'High fever, productive purulent cough, pleuritic chest pain, tachypnea, crackles on auscultation.',
    clinicalNotes: 'Diagnosed via chest X-ray infiltrates; stratify severity using CURB-65 criteria.',
    commonMisspellings: ['pnumonia', 'newmonia', 'pneumonea', 'pnomonia', 'pneumonia']
  },
  {
    id: 'dx-5',
    term: 'Myocardial Infarction',
    category: 'diagnosis',
    categoryLabel: 'Diagnosis / Cardiology',
    definition: 'Ischemic necrosis of myocardial tissue caused by acute thrombotic occlusion of a coronary artery.',
    indications: 'Substernal crushing chest pain radiating to left arm or jaw, diaphoresis, dyspnea.',
    clinicalNotes: 'Emergency condition requiring immediate ECG, troponin testing, and reperfusion therapy.',
    commonMisspellings: ['myocadial infarction', 'myocardial infarcation', 'myocardial infarctuin']
  },
  {
    id: 'dx-6',
    term: 'Gastroenteritis',
    category: 'diagnosis',
    categoryLabel: 'Diagnosis / Infectious Disease',
    definition: 'Inflammation of mucous membrane of the stomach and intestines caused by viruses or bacteria.',
    indications: 'Watery diarrhea, vomiting, abdominal cramps, low-grade fever, dehydration.',
    clinicalNotes: 'Oral rehydration therapy (ORT) is the cornerstone of clinical management.',
    commonMisspellings: ['gastroentritis', 'gastroenteritis', 'gastointestinal', 'gastroenteritus']
  },
  {
    id: 'dx-7',
    term: 'Hypothyroidism',
    category: 'diagnosis',
    categoryLabel: 'Diagnosis / Endocrine',
    definition: 'Deficiency of thyroid hormone production leading to clinical slowing of metabolic processes.',
    indications: 'Cold intolerance, weight gain, constipation, dry coarse skin, bradycardia, elevated TSH.',
    clinicalNotes: 'Most common etiology in iodine-replete regions is Hashimoto autoimmune thyroiditis.',
    commonMisspellings: ['hypothiroidism', 'hypothroidism', 'hipothyroidism', 'hypothyroidsm']
  },
  {
    id: 'dx-8',
    term: 'Multiple Sclerosis',
    category: 'diagnosis',
    categoryLabel: 'Diagnosis / Neurology',
    definition: 'Chronic autoimmune demyelinating disease of the central nervous system with variable relapses.',
    indications: 'Optic neuritis, Lhermitte sign, ataxia, spasticity, sensory paresthesias.',
    clinicalNotes: 'MRI shows periventricular white matter plaques (Dawson fingers); oligoclonal bands in CSF.',
    commonMisspellings: ['multiple sclorosis', 'multipul sclerosis', 'multiple sceloris']
  },
  {
    id: 'dx-9',
    term: 'Osteoarthritis',
    category: 'diagnosis',
    categoryLabel: 'Diagnosis / Rheumatology',
    definition: 'Degenerative joint disease involving progressive loss of articular cartilage and subchondral bone remodeling.',
    indications: 'Joint pain worsening with mechanical weight-bearing, morning stiffness lasting < 30 mins, crepitus.',
    clinicalNotes: 'Radiographs reveal joint space narrowing, subchondral sclerosis, and marginal osteophytes.',
    commonMisspellings: ['osteoarthrits', 'osteoarthritus', 'ostioarthritis', 'ostearthritis']
  },
  {
    id: 'dx-10',
    term: 'Tuberculosis',
    category: 'diagnosis',
    categoryLabel: 'Diagnosis / Infectious Disease',
    definition: 'Chronic bacterial infection caused by Mycobacterium tuberculosis, typically affecting the lungs.',
    indications: 'Chronic cough > 2-3 weeks, hemoptysis, night sweats, low-grade evening fevers, weight loss.',
    clinicalNotes: 'Screen with Mantoux tuberculin skin test / IGRA; confirm with sputum AFB smear and GeneXpert.',
    commonMisspellings: ['tuberculocis', 'tuberculoses', 'tuberclosis', 'tuberclocis']
  }
];

export const BENCHMARK_TEST_SUITE: BenchmarkTestCase[] = [
  {
    id: 'tc-1',
    misspelledQuery: 'paracetmol',
    targetTerm: 'Paracetamol',
    category: 'drug',
    errorType: 'Omission',
    expectedDistance: 1
  },
  {
    id: 'tc-2',
    misspelledQuery: 'dibetes',
    targetTerm: 'Diabetes Mellitus',
    category: 'diagnosis',
    errorType: 'Omission',
    expectedDistance: 2
  },
  {
    id: 'tc-3',
    misspelledQuery: 'amoxiclin',
    targetTerm: 'Amoxicillin',
    category: 'drug',
    errorType: 'Omission',
    expectedDistance: 2
  },
  {
    id: 'tc-4',
    misspelledQuery: 'hypertnnsion',
    targetTerm: 'Hypertension',
    category: 'symptom',
    errorType: 'Substitution',
    expectedDistance: 1
  },
  {
    id: 'tc-5',
    misspelledQuery: 'asthema',
    targetTerm: 'Bronchial Asthma',
    category: 'diagnosis',
    errorType: 'Insertion',
    expectedDistance: 1
  },
  {
    id: 'tc-6',
    misspelledQuery: 'ibuprofn',
    targetTerm: 'Ibuprofen',
    category: 'drug',
    errorType: 'Omission',
    expectedDistance: 1
  },
  {
    id: 'tc-7',
    misspelledQuery: 'cephlaxin',
    targetTerm: 'Cephalexin',
    category: 'drug',
    errorType: 'Omission',
    expectedDistance: 2
  },
  {
    id: 'tc-8',
    misspelledQuery: 'arrythmia',
    targetTerm: 'Arrhythmia',
    category: 'symptom',
    errorType: 'Substitution',
    expectedDistance: 1
  },
  {
    id: 'tc-9',
    misspelledQuery: 'dispnea',
    targetTerm: 'Dyspnea',
    category: 'symptom',
    errorType: 'Substitution',
    expectedDistance: 2
  },
  {
    id: 'tc-10',
    misspelledQuery: 'atorvastin',
    targetTerm: 'Atorvastatin',
    category: 'drug',
    errorType: 'Omission',
    expectedDistance: 1
  },
  {
    id: 'tc-11',
    misspelledQuery: 'pnumonia',
    targetTerm: 'Pneumonia',
    category: 'diagnosis',
    errorType: 'Omission',
    expectedDistance: 1
  },
  {
    id: 'tc-12',
    misspelledQuery: 'nausia',
    targetTerm: 'Nausea',
    category: 'symptom',
    errorType: 'Substitution',
    expectedDistance: 1
  },
  {
    id: 'tc-13',
    misspelledQuery: 'azithromicin',
    targetTerm: 'Azithromycin',
    category: 'drug',
    errorType: 'Substitution',
    expectedDistance: 1
  },
  {
    id: 'tc-14',
    misspelledQuery: 'cetrizine',
    targetTerm: 'Cetirizine',
    category: 'drug',
    errorType: 'Transposition',
    expectedDistance: 1
  },
  {
    id: 'tc-15',
    misspelledQuery: 'losartin',
    targetTerm: 'Losartan',
    category: 'drug',
    errorType: 'Substitution',
    expectedDistance: 1
  }
];
