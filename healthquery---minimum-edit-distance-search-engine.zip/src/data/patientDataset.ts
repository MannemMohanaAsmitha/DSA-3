import { Patient, PatientMedication } from '../types/index.ts';

// Vast pool of 130 first names
const FIRST_NAMES = [
  'Aravind', 'Priyanka', 'Suresh', 'Ananya', 'Rajesh', 'Lakshmi', 'Vikram', 'Sneha',
  'Rohan', 'Kavya', 'Aditya', 'Divya', 'Manoj', 'Deepa', 'Kiran', 'Swati',
  'Pradeep', 'Pooja', 'Naveen', 'Meera', 'Sai', 'Bhavana', 'Harish', 'Nandini',
  'Venkat', 'Sushma', 'Gautam', 'Anusha', 'Mohan', 'Ramya', 'Karthik', 'Sunita',
  'Vijay', 'Preethi', 'Santosh', 'Shalini', 'Ramesh', 'Aparna', 'Raghav', 'Geetha',
  'Varun', 'Sandhya', 'Ashok', 'Neelam', 'Mahesh', 'Rupa', 'Chetan', 'Archana',
  'Abhinav', 'Bhumika', 'Chaitanya', 'Deepthi', 'Eswar', 'Farhan', 'Gayatri', 'Hemanth',
  'Indira', 'Jagdish', 'Keerthi', 'Lokesh', 'Madhavi', 'Nikhil', 'Pallavi', 'Rahul',
  'Sangeetha', 'Tarun', 'Usha', 'Vamsi', 'Yamini', 'Zoya', 'Alok', 'Barkha',
  'Chinmay', 'Damodar', 'Eesha', 'Giridhar', 'Harita', 'Iqbal', 'Jayanth', 'Kalyani',
  'Laxman', 'Manasa', 'Niranjan', 'Padma', 'Rajeev', 'Sharada', 'Tejas', 'Uday',
  'Vandana', 'Yashwant', 'Anirudh', 'Bindu', 'Chirag', 'Dipti', 'Ganesh', 'Hema',
  'Ishaan', 'Jyothi', 'Krishnan', 'Lavanya', 'Mukesh', 'Namrata', 'Omkar', 'Pavani',
  'Ratan', 'Shruti', 'Tanvi', 'Utkarsh', 'Vidya', 'Zeeshan', 'Amartya', 'Bela',
  'Devendra', 'Gitanjali', 'Hardik', 'Ishita', 'Jitendra', 'Kalpana', 'Lalit', 'Maitreyi',
  'Nandita', 'Pranab', 'Radhika', 'Siddharth', 'Tanmay', 'Urmila', 'Vivek', 'Yuvraj'
];

// Vast pool of 100 surnames
const LAST_NAMES = [
  'Reddy', 'Sharma', 'Rao', 'Chowdary', 'Patel', 'Nair', 'Iyer', 'Verma',
  'Gupta', 'Kumar', 'Mishra', 'Deshmukh', 'Joshi', 'Kulkarni', 'Bose', 'Menon',
  'Pillai', 'Naidu', 'Shetty', 'Bhat', 'Saxena', 'Mukherjee', 'Chopra', 'Malhotra',
  'Agarwal', 'Chatterjee', 'Banerjee', 'Ghosh', 'Pandey', 'Trivedi', 'Bhattacharya', 'Sengupta',
  'Nambiar', 'Gowda', 'Hegde', 'Kamath', 'Prabhu', 'Ranganathan', 'Subramanian', 'Venkataraman',
  'Narayanan', 'Balakrishnan', 'Varma', 'Sethi', 'Kapoor', 'Khanna', 'Ahluwalia', 'Singhania',
  'Dubey', 'Tiwari', 'Shukla', 'Tripathi', 'Chaubey', 'Dwivedi', 'Goswami', 'Chauhan',
  'Rathore', 'Solanki', 'Bhardwaj', 'Purohit', 'Garg', 'Bansal', 'Goel', 'Mittal',
  'Agrawal', 'Soni', 'Modi', 'Shah', 'Mehta', 'Parikh', 'Doshi', 'Zaveri',
  'Dutta', 'Chakraborty', 'Ganguly', 'Mazumdar', 'Roy', 'Barman', 'Biswas', 'Das',
  'Sarkar', 'Bhowmick', 'Ghoshhal', 'Sen', 'Dey', 'Majhi', 'Kundu', 'Pramanik',
  'Talukdar', 'Barua', 'Medhi', 'Saikia', 'Bora', 'Gogoi', 'Deka', 'Goswami',
  'Kakkar', 'Batra', 'Talwar', 'Sachdev'
];

const MIDDLE_INITIALS = ['K.', 'V.', 'R.', 'S.', 'M.', 'N.', 'P.', 'B.', 'T.', 'A.', 'L.', 'G.', 'D.', 'C.'];

// Medical conditions and department profiles (over 65 distinct diagnostic entities)
interface DiagnosisTemplate {
  baseDiagnosis: string;
  department: string;
  subtypes: string[];
  symptomPool: string[];
  medicationPool: { drugName: string; dosages: string[]; frequencies: string[] }[];
}

const DIAGNOSES_TEMPLATES: DiagnosisTemplate[] = [
  {
    baseDiagnosis: 'Diabetes Mellitus',
    department: 'Endocrinology',
    subtypes: [
      'Type 2 Diabetes Mellitus with Peripheral Neuropathy',
      'Uncontrolled Type 2 Diabetes Mellitus (HbA1c 8.9%)',
      'Early-Onset Type 1 Diabetes Mellitus with Ketosis Risk',
      'Type 2 Diabetes Mellitus with Microalbuminuria',
      'Latent Autoimmune Diabetes in Adults (LADA)',
      'Gestational Diabetes Mellitus post-partum follow-up'
    ],
    symptomPool: ['Polydipsia', 'Polyuria', 'Fatigue', 'Paresthesia', 'Blurred Vision', 'Nocturia', 'Slow Wound Healing', 'Weight Loss'],
    medicationPool: [
      { drugName: 'Metformin', dosages: ['500mg', '850mg', '1000mg'], frequencies: ['Twice daily with meals', 'Once daily with dinner', 'Twice daily after food'] },
      { drugName: 'Atorvastatin', dosages: ['10mg', '20mg', '40mg'], frequencies: ['Once daily at bedtime', 'Once daily at night'] },
      { drugName: 'Glimepiride', dosages: ['1mg', '2mg', '3mg'], frequencies: ['Once daily before breakfast', 'Twice daily before food'] },
      { drugName: 'Sitagliptin', dosages: ['50mg', '100mg'], frequencies: ['Once daily in the morning', 'Once daily with breakfast'] },
      { drugName: 'Empagliflozin', dosages: ['10mg', '25mg'], frequencies: ['Once daily morning', 'Once daily with water'] }
    ]
  },
  {
    baseDiagnosis: 'Hypertension',
    department: 'Cardiology',
    subtypes: [
      'Essential Hypertension Stage 2 with LVH',
      'Refractory Arterial Hypertension',
      'Isolated Systolic Hypertension with Arterial Stiffness',
      'Hypertensive Urgency with Headache',
      'Renovascular Hypertension Secondary to RAS',
      'Essential Hypertension with Morning Surge'
    ],
    symptomPool: ['Headache', 'Arrhythmia', 'Tachycardia', 'Vertigo', 'Tinnitus', 'Epistaxis', 'Fatigue', 'Palpitations'],
    medicationPool: [
      { drugName: 'Losartan', dosages: ['25mg', '50mg', '100mg'], frequencies: ['Once daily morning', 'Twice daily'] },
      { drugName: 'Hydrochlorothiazide', dosages: ['12.5mg', '25mg'], frequencies: ['Once daily morning with water'] },
      { drugName: 'Amlodipine', dosages: ['2.5mg', '5mg', '10mg'], frequencies: ['Once daily morning', 'Once daily evening'] },
      { drugName: 'Telmisartan', dosages: ['20mg', '40mg', '80mg'], frequencies: ['Once daily with or without food'] },
      { drugName: 'Metoprolol Succinate', dosages: ['25mg', '50mg', '100mg'], frequencies: ['Once daily morning'] }
    ]
  },
  {
    baseDiagnosis: 'Bronchial Asthma',
    department: 'Pulmonology',
    subtypes: [
      'Moderate Persistent Bronchial Asthma',
      'Severe Allergic Bronchial Asthma with High IgE',
      'Acute Asthma Exacerbation (Moderate Severity)',
      'Exercise-Induced Bronchospasm',
      'Cough-Variant Asthma with Nocturnal Awakenings',
      'Aspirin-Exacerbated Respiratory Disease (AERD)'
    ],
    symptomPool: ['Dyspnea', 'Wheezing', 'Dry Cough', 'Chest Tightness', 'Tachycardia', 'Fatigue', 'Orthopnea'],
    medicationPool: [
      { drugName: 'Albuterol', dosages: ['100mcg', '90mcg'], frequencies: ['2 puffs every 4-6 hours PRN', '2 puffs before physical exertion'] },
      { drugName: 'Cetirizine', dosages: ['5mg', '10mg'], frequencies: ['Once daily at bedtime', 'Once daily evening'] },
      { drugName: 'Budesonide / Formoterol', dosages: ['160/4.5mcg', '320/9mcg'], frequencies: ['1 inhalation twice daily', '2 inhalations twice daily'] },
      { drugName: 'Montelukast', dosages: ['10mg', '5mg'], frequencies: ['Once daily at night'] }
    ]
  },
  {
    baseDiagnosis: 'Pneumonia',
    department: 'Pulmonology',
    subtypes: [
      'Community-Acquired Pneumonia (Right Lower Lobe)',
      'Bilateral Multilobar Bronchopneumonia',
      'Atypical Mycoplasma Pneumonia',
      'Aspiration Pneumonitis with Secondary Infection',
      'Post-Viral Bacterial Pneumonia'
    ],
    symptomPool: ['Dyspnea', 'Productive Sputum', 'Fever', 'Fatigue', 'Pleuritic Chest Pain', 'Tachycardia', 'Chills'],
    medicationPool: [
      { drugName: 'Amoxicillin', dosages: ['500mg', '875mg'], frequencies: ['Three times daily for 7 days', 'Twice daily after meals'] },
      { drugName: 'Azithromycin', dosages: ['250mg', '500mg'], frequencies: ['Once daily for 5 days', 'Once daily for 3 days'] },
      { drugName: 'Paracetamol', dosages: ['500mg', '650mg'], frequencies: ['Every 6 hours as needed for fever', 'SOS maximum 4 doses daily'] },
      { drugName: 'Ceftriaxone', dosages: ['1g', '2g'], frequencies: ['IV once daily infusion'] }
    ]
  },
  {
    baseDiagnosis: 'Osteoarthritis',
    department: 'Orthopedics',
    subtypes: [
      'Bilateral Knee Osteoarthritis (Kellgren-Lawrence Grade III)',
      'Primary Hip Osteoarthritis with Limited Abduction',
      'Cervical Spondylosis with Radicular Pain',
      'Lumbar Spondylosis with Facet Arthropathy',
      'Nodal Hand Osteoarthritis with Heberden Nodes'
    ],
    symptomPool: ['Arthralgia', 'Joint Stiffness', 'Morning Stiffness', 'Crepitus', 'Reduced Mobility', 'Myalgia', 'Swelling'],
    medicationPool: [
      { drugName: 'Ibuprofen', dosages: ['400mg', '600mg'], frequencies: ['Twice daily after food', 'Three times daily with meals'] },
      { drugName: 'Paracetamol', dosages: ['650mg', '1000mg'], frequencies: ['Three times daily as needed', 'Twice daily'] },
      { drugName: 'Glucosamine Sulfate', dosages: ['500mg', '1500mg'], frequencies: ['Once daily with water'] },
      { drugName: 'Tramadol / Paracetamol', dosages: ['37.5/325mg'], frequencies: ['Once or twice daily SOS for severe breakthrough pain'] }
    ]
  },
  {
    baseDiagnosis: 'Hypothyroidism',
    department: 'Endocrinology',
    subtypes: [
      'Primary Autoimmune Hypothyroidism (Hashimoto Thyroiditis)',
      'Subclinical Hypothyroidism with High TSH',
      'Post-Thyroidectomy Hypothyroidism',
      'Hypothyroidism with Mild Periorbital Edema'
    ],
    symptomPool: ['Fatigue', 'Cold Intolerance', 'Weight Gain', 'Dry Skin', 'Constipation', 'Bradycardia', 'Myalgia', 'Alopecia'],
    medicationPool: [
      { drugName: 'Levothyroxine', dosages: ['25mcg', '50mcg', '75mcg', '88mcg', '100mcg', '112mcg', '125mcg'], frequencies: ['Once daily 30-60 mins before breakfast with water'] },
      { drugName: 'Vitamin D3', dosages: ['60000 IU', '2000 IU'], frequencies: ['Once weekly with milk', 'Once daily with meals'] }
    ]
  },
  {
    baseDiagnosis: 'Gastroenteritis',
    department: 'Gastroenterology',
    subtypes: [
      'Acute Viral Gastroenteritis with Dehydration',
      'Infectious Bacterial Dysentery (Campylobacter)',
      'Foodborne Enterocolitis with Severe Cramping',
      'Antibiotic-Associated Enteritis'
    ],
    symptomPool: ['Nausea', 'Vomiting', 'Abdominal Cramps', 'Watery Diarrhea', 'Dehydration', 'Low-Grade Fever', 'Fatigue'],
    medicationPool: [
      { drugName: 'Ciprofloxacin', dosages: ['500mg'], frequencies: ['Twice daily for 5 days', 'Twice daily 1 hour before food'] },
      { drugName: 'Omeprazole', dosages: ['20mg', '40mg'], frequencies: ['Once daily 30 minutes before breakfast'] },
      { drugName: 'Oral Rehydration Salts', dosages: ['1 sachet in 1L water'], frequencies: ['Sip freely after each loose stool'] },
      { drugName: 'Ondansetron', dosages: ['4mg', '8mg'], frequencies: ['Every 8 hours as needed for nausea'] }
    ]
  },
  {
    baseDiagnosis: 'Atherosclerosis & CAD',
    department: 'Cardiology',
    subtypes: [
      'Coronary Artery Disease with Stable Angina (CCS Class II)',
      'Atherosclerosis post-Percutaneous Coronary Intervention',
      'Peripheral Arterial Occlusive Disease with Claudication',
      'Carotid Artery Atherosclerosis with 50% Stenosis'
    ],
    symptomPool: ['Dyspnea', 'Arrhythmia', 'Angina / Chest Discomfort', 'Fatigue', 'Intermittent Claudication', 'Palpitations'],
    medicationPool: [
      { drugName: 'Atorvastatin', dosages: ['20mg', '40mg', '80mg'], frequencies: ['Once daily at bedtime'] },
      { drugName: 'Aspirin', dosages: ['75mg', '100mg'], frequencies: ['Once daily with or after food'] },
      { drugName: 'Clopidogrel', dosages: ['75mg'], frequencies: ['Once daily morning'] },
      { drugName: 'Metoprolol Tartrate', dosages: ['25mg', '50mg'], frequencies: ['Twice daily with meals'] }
    ]
  },
  {
    baseDiagnosis: 'Migraine Cephalea',
    department: 'Neurology',
    subtypes: [
      'Chronic Migraine without Aura',
      'Classic Migraine with Visual Scintillating Aura',
      'Frequent Episodic Tension Headache with Cervicogenic Trigger',
      'Vestibular Migraine with Episodic Vertigo'
    ],
    symptomPool: ['Headache', 'Photophobia', 'Phonophobia', 'Nausea', 'Vertigo', 'Neck Stiffness', 'Blurred Vision'],
    medicationPool: [
      { drugName: 'Paracetamol', dosages: ['650mg', '1000mg'], frequencies: ['At onset of aura, repeat in 4 hrs PRN'] },
      { drugName: 'Ibuprofen', dosages: ['400mg'], frequencies: ['Every 8 hours with food as needed'] },
      { drugName: 'Propranolol', dosages: ['20mg', '40mg'], frequencies: ['Twice daily for prophylaxis'] },
      { drugName: 'Flunarizine', dosages: ['5mg', '10mg'], frequencies: ['Once daily at bedtime'] }
    ]
  },
  {
    baseDiagnosis: 'Peripheral Neuropathy',
    department: 'Neurology',
    subtypes: [
      'Diabetic Distal Symmetrical Polyneuropathy',
      'Idiopathic Sensory Neuropathy with Allodynia',
      'Bilateral Carpal Tunnel Syndrome (Median Nerve Entrapment)',
      'Chemotherapy-Induced Peripheral Neuropathy'
    ],
    symptomPool: ['Paresthesia', 'Numbness', 'Burning Dysesthesia', 'Myalgia', 'Loss of Vibration Sense', 'Cramps'],
    medicationPool: [
      { drugName: 'Gabapentin', dosages: ['100mg', '300mg', '600mg'], frequencies: ['Once daily at bedtime', 'Three times daily'] },
      { drugName: 'Pregabalin', dosages: ['75mg', '150mg'], frequencies: ['Once daily at bedtime', 'Twice daily'] },
      { drugName: 'Methylcobalamin (B12)', dosages: ['1500mcg'], frequencies: ['Once daily with breakfast'] },
      { drugName: 'Duloxetine', dosages: ['30mg', '60mg'], frequencies: ['Once daily morning with breakfast'] }
    ]
  },
  {
    baseDiagnosis: 'Allergic Rhinosinusitis',
    department: 'ENT & Allergy',
    subtypes: [
      'Perennial Allergic Rhinosinusitis with Turbinate Edema',
      'Seasonal Allergic Pollen Rhinitis with Conjunctivitis',
      'Chronic Maxillary Sinusitis with Post-Nasal Drip',
      'Vasomotor Non-Allergic Rhinitis'
    ],
    symptomPool: ['Rhinorrhea', 'Nasal Congestion', 'Sneezing Paroxysms', 'Headache', 'Facial Pressure', 'Pruritus of Palate'],
    medicationPool: [
      { drugName: 'Cetirizine', dosages: ['10mg'], frequencies: ['Once daily at night'] },
      { drugName: 'Fluticasone Furoate Nasal Spray', dosages: ['27.5mcg/spray'], frequencies: ['1 spray each nostril once daily'] },
      { drugName: 'Montelukast', dosages: ['10mg'], frequencies: ['Once daily evening'] },
      { drugName: 'Saline Nasal Irrigation', dosages: ['100ml buffer'], frequencies: ['Twice daily before nasal spray'] }
    ]
  },
  {
    baseDiagnosis: 'Multiple Sclerosis',
    department: 'Neurology',
    subtypes: [
      'Relapsing-Remitting Multiple Sclerosis (RRMS)',
      'Clinically Isolated Syndrome with Demyelination',
      'Secondary Progressive MS with Mild Spasticity'
    ],
    symptomPool: ['Paresthesia', 'Fatigue', 'Visual Blurring', 'Ataxia', 'Lhermitte Sign', 'Spasticity', 'Urinary Urgency'],
    medicationPool: [
      { drugName: 'Glatiramer Acetate', dosages: ['20mg/mL'], frequencies: ['Subcutaneous injection once daily'] },
      { drugName: 'Baclofen', dosages: ['10mg', '20mg'], frequencies: ['Three times daily for spasticity'] },
      { drugName: 'Modafinil', dosages: ['100mg'], frequencies: ['Once daily morning for severe fatigue'] }
    ]
  },
  {
    baseDiagnosis: 'Tuberculosis',
    department: 'Infectious Disease',
    subtypes: [
      'Pulmonary Tuberculosis (Category I DOTS - Intensive Phase)',
      'Tuberculous Pleural Effusion (Left Hemithorax)',
      'Latent TB Infection on Preventive Therapy'
    ],
    symptomPool: ['Chronic Cough', 'Hemoptysis', 'Night Sweats', 'Low-Grade Evening Fever', 'Weight Loss', 'Fatigue'],
    medicationPool: [
      { drugName: 'Isoniazid', dosages: ['300mg'], frequencies: ['Once daily on empty stomach'] },
      { drugName: 'Rifampicin', dosages: ['450mg', '600mg'], frequencies: ['Once daily 1 hour before food'] },
      { drugName: 'Pyrazinamide', dosages: ['1500mg'], frequencies: ['Once daily with food'] },
      { drugName: 'Ethambutol', dosages: ['1000mg'], frequencies: ['Once daily with water'] }
    ]
  },
  {
    baseDiagnosis: 'Chronic Kidney Disease',
    department: 'Nephrology',
    subtypes: [
      'Chronic Kidney Disease Stage 3a (eGFR 52 mL/min)',
      'Diabetic Nephropathy Stage 3b with Proteinuria',
      'Hypertensive Nephrosclerosis Stage 2'
    ],
    symptomPool: ['Fatigue', 'Ankle Edema', 'Foamy Urine', 'Hypertension', 'Nocturia', 'Loss of Appetite'],
    medicationPool: [
      { drugName: 'Losartan', dosages: ['25mg', '50mg'], frequencies: ['Once daily morning with nephro monitoring'] },
      { drugName: 'Torsemide', dosages: ['10mg', '20mg'], frequencies: ['Once daily morning after food'] },
      { drugName: 'Calcium Acetate', dosages: ['667mg'], frequencies: ['One tablet with each meal as phosphate binder'] }
    ]
  },
  {
    baseDiagnosis: 'Gastroesophageal Reflux (GERD)',
    department: 'Gastroenterology',
    subtypes: [
      'Erosive Esophagitis (Los Angeles Classification Grade B)',
      'Non-Erosive Reflux Disease (NERD) with Regurgitation',
      'Laryngopharyngeal Reflux with Globus Sensation'
    ],
    symptomPool: ['Epigastric Burning', 'Acid Regurgitation', 'Dysphagia', 'Globus Hystericus', 'Nocturnal Cough', 'Belching'],
    medicationPool: [
      { drugName: 'Omeprazole', dosages: ['20mg', '40mg'], frequencies: ['Once daily 30 mins before breakfast'] },
      { drugName: 'Pantoprazole', dosages: ['40mg'], frequencies: ['Once daily before morning meals'] },
      { drugName: 'Sucralfate', dosages: ['1g/10mL'], frequencies: ['10mL four times daily 1 hr before meals & bed'] }
    ]
  },
  {
    baseDiagnosis: 'Atrial Fibrillation',
    department: 'Cardiology',
    subtypes: [
      'Paroxysmal Atrial Fibrillation with Rapid Ventricular Response',
      'Persistent Non-Valvular Atrial Fibrillation',
      'Atrial Fibrillation with Controlled Ventricular Rate'
    ],
    symptomPool: ['Arrhythmia', 'Tachycardia', 'Palpitations', 'Dyspnea', 'Dizziness', 'Fatigue', 'Syncope Precursor'],
    medicationPool: [
      { drugName: 'Apixaban', dosages: ['2.5mg', '5mg'], frequencies: ['Twice daily with or without food'] },
      { drugName: 'Metoprolol Succinate', dosages: ['50mg', '100mg'], frequencies: ['Once daily morning'] },
      { drugName: 'Digoxin', dosages: ['0.125mg', '0.25mg'], frequencies: ['Once daily with serum monitoring'] }
    ]
  },
  {
    baseDiagnosis: 'Rheumatoid Arthritis',
    department: 'Rheumatology',
    subtypes: [
      'Seropositive Rheumatoid Arthritis (DAS28 High Disease Activity)',
      'Early Inflammatory Polyarthritis with Morning Stiffness',
      'Rheumatoid Arthritis in Clinical Remission on DMARDs'
    ],
    symptomPool: ['Arthralgia', 'Morning Stiffness > 1 Hour', 'Joint Swelling (MCP/PIP)', 'Fatigue', 'Low-Grade Malaise'],
    medicationPool: [
      { drugName: 'Methotrexate', dosages: ['10mg', '15mg', '20mg'], frequencies: ['Once weekly on every Sunday night'] },
      { drugName: 'Folic Acid', dosages: ['5mg'], frequencies: ['Once weekly on Tuesday morning'] },
      { drugName: 'Hydroxychloroquine', dosages: ['200mg', '400mg'], frequencies: ['Once daily with evening meal'] }
    ]
  }
];

const PHYSICIANS_POOL = [
  'Dr. A. V. Rao, MD (Internal Medicine)',
  'Dr. S. K. Gupta, MD, DM (Cardiology)',
  'Dr. Meenakshi Sundaram, MS, MCh (Orthopedics)',
  'Dr. K. V. Sharma, MD, DM (Endocrinology)',
  'Dr. Priya Radhakrishnan, MD (Pulmonology)',
  'Dr. R. C. Chowdary, MD (General Medicine)',
  'Dr. Anita Joshi, DNB (Neurology)',
  'Dr. Vikram Patel, MD, DM (Gastroenterology)',
  'Dr. Sunita Deshmukh, MD (Nephrology)',
  'Dr. Rajeshwar Naidu, MD, DM (Rheumatology)',
  'Dr. Vandana Saxena, MS (ENT & Otolaryngology)',
  'Dr. Hemanth Kumar, MD (Infectious Diseases)',
  'Dr. Bhavana Reddy, MD (Critical Care & ICU)',
  'Dr. Chetan Kulkarni, DNB (Cardiology)',
  'Dr. Shalini Iyer, MD (Geriatric Medicine)',
  'Dr. Naveen Menon, MD (Endocrinology)'
];

const BLOOD_GROUPS = ['O+', 'B+', 'A+', 'AB+', 'O-', 'B-', 'A-', 'AB-'];
const STATUS_OPTIONS: Patient['status'][] = ['Inpatient', 'Outpatient', 'Discharged', 'Critical'];

/**
 * Pseudo-random deterministic number generator to guarantee reproducible,
 * yet 100% unique details for each of the 1,000 patient records.
 */
function seededRandom(seed: number): () => number {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

/**
 * Generates 1,000 completely unique, differentiated patient records.
 * Ensures:
 * - Every patient has a unique full name
 * - Every patient has a unique phone number
 * - Every patient has distinct age, vitals, diagnosis subtype, personalized symptom combinations,
 *   and individual medication dosages/frequencies.
 */
export function generate1000Patients(): Patient[] {
  const patients: Patient[] = [];
  const usedNames = new Set<string>();
  const usedPhones = new Set<string>();

  for (let i = 1; i <= 1000; i++) {
    const rng = seededRandom(i * 7919 + 104729);

    // 1. Guaranteed unique patient name
    let name = '';
    let nameAttempt = 0;
    while (!name || usedNames.has(name)) {
      const fnIdx = Math.floor(rng() * FIRST_NAMES.length);
      const lnIdx = Math.floor(rng() * LAST_NAMES.length);
      const fn = FIRST_NAMES[fnIdx];
      const ln = LAST_NAMES[lnIdx];

      if (nameAttempt < 2) {
        name = `${fn} ${ln}`;
      } else {
        const midIdx = Math.floor(rng() * MIDDLE_INITIALS.length);
        name = `${fn} ${MIDDLE_INITIALS[midIdx]} ${ln}`;
      }
      nameAttempt++;
    }
    usedNames.add(name);

    // 2. Guaranteed unique phone contact
    let contact = '';
    while (!contact || usedPhones.has(contact)) {
      const prefix = ['98480', '94401', '91772', '89781', '79890', '96180', '99890', '88970', '90001', '95020'][
        Math.floor(rng() * 10)
      ];
      const randNum = 10000 + Math.floor(rng() * 90000);
      contact = `+91 ${prefix} ${randNum}`;
    }
    usedPhones.add(contact);

    // 3. Demographics
    const age = 18 + Math.floor(rng() * 72); // 18 to 89
    const genderRoll = rng();
    const gender: Patient['gender'] = genderRoll < 0.49 ? 'Male' : genderRoll < 0.98 ? 'Female' : 'Other';
    const bloodGroup = BLOOD_GROUPS[Math.floor(rng() * BLOOD_GROUPS.length)];

    // 4. Admission date distributed over past 365 days
    const dayOffset = Math.floor(rng() * 365);
    const dateObj = new Date(2026, 8, 18 - dayOffset);
    const admissionDate = dateObj.toISOString().split('T')[0];

    // 5. Diagnosis and Department Selection
    const template = DIAGNOSES_TEMPLATES[i % DIAGNOSES_TEMPLATES.length];
    const subtypeIdx = Math.floor(rng() * template.subtypes.length);
    const diagnosis = template.subtypes[subtypeIdx];
    const department = template.department;

    // 6. Distinct personalized symptoms (2 to 5 symptoms per patient)
    const shuffledSymptoms = [...template.symptomPool].sort(() => rng() - 0.5);
    const symCount = 2 + Math.floor(rng() * Math.min(4, shuffledSymptoms.length - 1));
    const symptoms = shuffledSymptoms.slice(0, symCount);

    // 7. Distinct personalized medications with varying dosages & posology
    const medCount = 1 + Math.floor(rng() * Math.min(3, template.medicationPool.length));
    const shuffledMeds = [...template.medicationPool].sort(() => rng() - 0.5);
    const medications: PatientMedication[] = [];

    for (let m = 0; m < medCount; m++) {
      const medItem = shuffledMeds[m];
      const dosage = medItem.dosages[Math.floor(rng() * medItem.dosages.length)];
      const frequency = medItem.frequencies[Math.floor(rng() * medItem.frequencies.length)];
      medications.push({
        drugName: medItem.drugName,
        dosage,
        frequency
      });
    }

    // 8. Attending Physician & Care Status
    const physician = PHYSICIANS_POOL[Math.floor(rng() * PHYSICIANS_POOL.length)];
    const statusRoll = rng();
    const status: Patient['status'] =
      statusRoll < 0.2
        ? 'Inpatient'
        : statusRoll < 0.28
        ? 'Critical'
        : statusRoll < 0.75
        ? 'Outpatient'
        : 'Discharged';

    // 9. Personalized Vitals & Progress Note
    const sysBP = 110 + Math.floor(rng() * 45);
    const diaBP = 70 + Math.floor(rng() * 25);
    const hr = 62 + Math.floor(rng() * 38);
    const spo2 = 94 + Math.floor(rng() * 6);
    const temp = (97.8 + rng() * 2.6).toFixed(1);
    const bloodSugar = 85 + Math.floor(rng() * 140);
    const painScore = Math.floor(rng() * 8);

    const medSummary = medications.map((m) => `${m.drugName} ${m.dosage}`).join(', ');
    const notes = `Clinical Evaluation on ${admissionDate}: Patient presents with ${symptoms.join(', ').toLowerCase()}. Vitals recorded: BP ${sysBP}/${diaBP} mmHg, HR ${hr} bpm, SpO2 ${spo2}%, Temp ${temp}°F, Random Blood Sugar ${bloodSugar} mg/dL, Pain Score ${painScore}/10. Prescribed regimen initiated (${medSummary}). Condition categorized as ${status}; under clinical management of ${physician.split(',')[0]} in ${department}.`;

    patients.push({
      id: `PID-${1000 + i}`,
      name,
      age,
      gender,
      bloodGroup,
      contact,
      admissionDate,
      diagnosis,
      symptoms,
      medications,
      attendingPhysician: physician,
      department,
      status,
      notes
    });
  }

  return patients;
}

// Storage key incremented to v3 to guarantee all previous identical cached records are replaced
const STORAGE_KEY = 'healthquery_patients_v3_unique';

/**
 * Loads patient records from localStorage or creates the brand new completely differentiated records
 */
export function getStoredPatients(): Patient[] {
  try {
    // Clear old versions if present
    localStorage.removeItem('healthquery_patients_v1');
    localStorage.removeItem('healthquery_patients_v2');

    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length >= 100) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Error reading stored patients, initializing seed', e);
  }

  // Generate initial 1,000 completely unique patients
  const seed = generate1000Patients();
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(seed));
  } catch (e) {
    console.warn('LocalStorage limit reached when caching 1,000 patients', e);
  }
  return seed;
}

/**
 * Saves patients array to localStorage
 */
export function savePatients(patients: Patient[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(patients));
  } catch (e) {
    console.error('Failed to save patients to localStorage', e);
  }
}

/**
 * Resets back to clean 1,000 differentiated seed patients
 */
export function resetToSeedPatients(): Patient[] {
  const seed = generate1000Patients();
  savePatients(seed);
  return seed;
}
