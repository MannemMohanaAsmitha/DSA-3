import { useState, useMemo } from 'react';
import { Grid, Sparkles, HelpCircle, ArrowDownRight, Layers, Play, RefreshCw } from 'lucide-react';
import { computeDetailedDPMatrix } from '../utils/levenshtein.ts';

interface DPMatrixExplorerProps {
  initialS1?: string;
  initialS2?: string;
}

export function DPMatrixExplorer({ initialS1 = 'dibetes', initialS2 = 'diabetes' }: DPMatrixExplorerProps) {
  const [string1, setString1] = useState<string>(initialS1);
  const [string2, setString2] = useState<string>(initialS2);
  const [selectedCell, setSelectedCell] = useState<{ i: number; j: number } | null>(null);

  const dpResult = useMemo(() => {
    return computeDetailedDPMatrix(string1 || 'a', string2 || 'a');
  }, [string1, string2]);

  const presetPairs = [
    { s1: 'dibetes', s2: 'diabetes', label: 'Diabetes (Omission)' },
    { s1: 'paracetmol', s2: 'paracetamol', label: 'Paracetamol (Omission)' },
    { s1: 'asthema', s2: 'asthma', label: 'Asthma (Insertion)' },
    { s1: 'hypertnnsion', s2: 'hypertension', label: 'Hypertension (Subst)' },
    { s1: 'nausia', s2: 'nausea', label: 'Nausea (Subst)' },
    { s1: 'dispnea', s2: 'dyspnea', label: 'Dyspnea (Subst)' },
  ];

  const optimalPathSet = useMemo(() => {
    const set = new Set<string>();
    dpResult.optimalPath.forEach(([i, j]) => {
      set.add(`${i},${j}`);
    });
    return set;
  }, [dpResult]);

  return (
    <div className="space-y-6" id="dp-matrix-explorer-container">
      {/* Header & Controls */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <Grid className="w-5 h-5 text-amber-400" />
              <h2 className="text-xl font-bold text-white">
                Dynamic Programming Matrix Visualizer
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Step-by-step bottom-up Levenshtein distance matrix computation with optimal backtracking path
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-mono text-xs font-semibold">
              Final Edit Distance: {dpResult.distance}
            </span>
          </div>
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-5">
          <div>
            <label htmlFor="dp-source-str" className="block text-xs font-mono text-slate-300 mb-1">
              Source Query String (s1):
            </label>
            <input
              type="text"
              id="dp-source-str"
              maxLength={15}
              value={string1}
              onChange={(e) => setString1(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl text-white font-mono text-sm focus:outline-none"
            />
          </div>

          <div>
            <label htmlFor="dp-target-str" className="block text-xs font-mono text-slate-300 mb-1">
              Target Dictionary String (s2):
            </label>
            <input
              type="text"
              id="dp-target-str"
              maxLength={15}
              value={string2}
              onChange={(e) => setString2(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl text-white font-mono text-sm focus:outline-none"
            />
          </div>
        </div>

        {/* Preset Selector */}
        <div className="flex flex-wrap items-center gap-2 mt-4 pt-3 border-t border-slate-800">
          <span className="text-xs font-mono text-slate-400">Sample Medical Pairs:</span>
          {presetPairs.map((p) => (
            <button
              key={p.label}
              type="button"
              onClick={() => {
                setString1(p.s1);
                setString2(p.s2);
                setSelectedCell(null);
              }}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-300 transition cursor-pointer"
            >
              {p.s1} ➔ {p.s2}
            </button>
          ))}
        </div>
      </div>

      {/* DP Matrix Table & Formula explanation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Visual 2D Matrix */}
        <div className="lg:col-span-8 bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>2D DP Matrix (Row: S1 &quot;{string1}&quot;, Col: S2 &quot;{string2}&quot;)</span>
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5 text-amber-300">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <span>Optimal Path</span>
              </span>
              <span className="flex items-center gap-1.5 text-slate-400">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-700" />
                <span>Matrix Cell</span>
              </span>
            </div>
          </div>

          {/* Matrix Scrollable Container */}
          <div className="overflow-x-auto pb-2">
            <table className="border-collapse font-mono text-xs mx-auto">
              <thead>
                <tr>
                  <th className="p-2 border border-slate-800 bg-slate-950 text-slate-500 text-center">
                    i\j
                  </th>
                  <th className="p-2 border border-slate-800 bg-slate-950 text-slate-400 text-center">
                    ε
                  </th>
                  {string2.split('').map((char, j) => (
                    <th
                      key={j}
                      className="p-2 border border-slate-800 bg-slate-950 text-amber-400 font-bold text-center min-w-[36px]"
                    >
                      {char}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {dpResult.matrix.map((row, i) => {
                  const rowChar = i === 0 ? 'ε' : string1[i - 1];
                  return (
                    <tr key={i}>
                      <th
                        className={`p-2 border border-slate-800 bg-slate-950 text-center font-bold ${
                          i === 0 ? 'text-slate-400' : 'text-amber-400'
                        }`}
                      >
                        {rowChar}
                      </th>
                      {row.map((val, j) => {
                        const isPath = optimalPathSet.has(`${i},${j}`);
                        const isSelected = selectedCell?.i === i && selectedCell?.j === j;

                        return (
                          <td
                            key={j}
                            onClick={() => setSelectedCell({ i, j })}
                            className={`p-2.5 border text-center font-bold transition-colors cursor-pointer ${
                              isSelected
                                ? 'bg-blue-600 text-white ring-2 ring-blue-400 border-blue-400'
                                : isPath
                                ? 'bg-amber-500 text-slate-950 border-amber-400'
                                : 'border-slate-800/80 hover:bg-slate-800 text-slate-300'
                            }`}
                            title={`D[${i}, ${j}] = ${val}`}
                          >
                            {val}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="text-[11px] text-slate-400 font-mono flex items-center justify-between pt-2 border-t border-slate-800">
            <span>Click any cell to inspect its dynamic programming recurrence origin.</span>
            <span>Matrix size: {string1.length + 1} × {string2.length + 1} cells</span>
          </div>
        </div>

        {/* Algorithm Recurrence & Step Explanation Panel */}
        <div className="lg:col-span-4 space-y-4">
          {/* Recurrence Equation Box */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-3">
            <h4 className="text-xs font-bold font-mono text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4" />
              <span>DP Recurrence Formula</span>
            </h4>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-slate-200 space-y-2 leading-relaxed">
              <div className="text-amber-300 font-bold">
                D[i, j] = min &#123;
              </div>
              <div className="pl-4 space-y-1 text-slate-300 text-[11px]">
                <div>
                  <span className="text-rose-400">D[i-1, j] + 1</span>{' '}
                  <span className="text-slate-500">(Deletion)</span>
                </div>
                <div>
                  <span className="text-blue-400">D[i, j-1] + 1</span>{' '}
                  <span className="text-slate-500">(Insertion)</span>
                </div>
                <div>
                  <span className="text-emerald-400">D[i-1, j-1] + cost</span>{' '}
                  <span className="text-slate-500">(cost = s1[i]==s2[j] ? 0 : 1)</span>
                </div>
              </div>
              <div className="text-amber-300 font-bold">&#125;</div>
            </div>

            {selectedCell && (
              <div className="p-3.5 rounded-xl bg-blue-950/40 border border-blue-800/60 font-mono text-xs text-blue-200 space-y-1">
                <div className="font-bold text-blue-300">
                  Cell D[{selectedCell.i}, {selectedCell.j}] = {dpResult.matrix[selectedCell.i][selectedCell.j]}
                </div>
                <div className="text-[11px] text-slate-300">
                  Substrings: &quot;{string1.substring(0, selectedCell.i)}&quot; ➔ &quot;{string2.substring(0, selectedCell.j)}&quot;
                </div>
              </div>
            )}
          </div>

          {/* Operations Trace Log */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-3">
            <h4 className="text-xs font-bold font-mono text-slate-300 uppercase tracking-wider">
              Optimal Backtrack Alignment ({dpResult.steps.length} steps)
            </h4>

            <div className="space-y-2 max-h-64 overflow-y-auto pr-1 text-xs font-mono scrollbar-thin">
              {dpResult.steps.map((step) => (
                <div
                  key={step.stepIndex}
                  className={`p-2.5 rounded-lg border text-xs flex items-center justify-between gap-2 ${
                    step.operation === 'match'
                      ? 'bg-slate-950 border-emerald-500/30 text-emerald-300'
                      : step.operation === 'insert'
                      ? 'bg-slate-950 border-blue-500/30 text-blue-300'
                      : step.operation === 'delete'
                      ? 'bg-slate-950 border-rose-500/30 text-rose-300'
                      : 'bg-slate-950 border-amber-500/30 text-amber-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="font-bold">#{step.stepIndex}</span>
                    <span className="uppercase text-[10px] px-1.5 py-0.5 rounded bg-slate-800">
                      {step.operation}
                    </span>
                    <span className="text-white">
                      &apos;{step.char1}&apos; ➔ &apos;{step.char2}&apos;
                    </span>
                  </div>
                  <span className="font-bold text-[11px]">
                    Cost: +{step.cost}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
