import { Activity, Search, GitCompare, Grid, BarChart3, Presentation, BookOpen, Users, Database } from 'lucide-react';

export type ActiveTab = 'patients' | 'search' | 'comparison' | 'dp-matrix' | 'benchmark' | 'presentation' | 'corpus' | 'team';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  patientCount?: number;
}

export function Header({ activeTab, setActiveTab, patientCount = 1000 }: HeaderProps) {
  const navItems: { id: ActiveTab; label: string; icon: typeof Search; countBadge?: string }[] = [
    { id: 'patients', label: '1,000 Patients (DSA)', icon: Database, countBadge: String(patientCount) },
    { id: 'search', label: 'Live Query Engine', icon: Search },
    { id: 'comparison', label: 'Exact vs. Fuzzy Test', icon: GitCompare },
    { id: 'dp-matrix', label: 'DP Matrix Visualizer', icon: Grid },
    { id: 'benchmark', label: 'Benchmark & Results (96%)', icon: BarChart3, countBadge: '96%' },
    { id: 'presentation', label: 'Project Deck (Slides 1-7)', icon: Presentation, countBadge: '7' },
    { id: 'corpus', label: 'Medical Corpus', icon: BookOpen, countBadge: '35+' },
    { id: 'team', label: 'Team Members', icon: Users, countBadge: '4' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800">
      {/* Top Academic Ribbon */}
      <div className="bg-gradient-to-r from-amber-500/15 via-blue-500/10 to-amber-500/15 border-b border-slate-800/80 px-4 py-1.5 text-xs text-slate-300">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 font-mono">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-amber-400 font-semibold">B.Tech Final Year Project</span>
            <span className="text-slate-600">|</span>
            <span className="text-slate-300">Department of Computer Science</span>
          </div>
          <div className="text-slate-400 font-mono text-[11px] hidden sm:flex items-center gap-3">
            <span>Minimum Edit Distance Query Engine</span>
            <span className="text-slate-600">•</span>
            <span className="text-amber-300/90 font-medium">G. Laasya & Team</span>
          </div>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 shadow-lg shadow-amber-500/20 shrink-0">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight leading-tight">
                HealthQuery Engine
              </h1>
              <span className="px-2 py-0.5 text-[11px] font-semibold rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                Levenshtein DP
              </span>
            </div>
            <p className="text-xs text-slate-400 line-clamp-1">
              Efficient Text Search & Retrieval for Healthcare Systems
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none" aria-label="Main Navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-btn-${item.id}`}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 shadow-sm font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
                {item.countBadge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                      isActive ? 'bg-slate-900/20 text-slate-950 font-bold' : 'bg-slate-800 text-amber-400'
                    }`}
                  >
                    {item.countBadge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
