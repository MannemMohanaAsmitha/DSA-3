import { ArrowRight, Sparkles, Terminal, CheckCircle2, ShieldCheck, Zap } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroBannerProps {
  onSelectQuery: (term: string) => void;
  onExploreDP: (s1: string, s2: string) => void;
  onNavigatePatients?: () => void;
}

export function HeroBanner({ onSelectQuery, onExploreDP, onNavigatePatients }: HeroBannerProps) {
  const sampleTypos = [
    { typo: 'paracetmol', intended: 'Paracetamol', type: 'Omission' },
    { typo: 'dibetes', intended: 'Diabetes Mellitus', type: 'Omission' },
    { typo: 'hypertnnsion', intended: 'Hypertension', type: 'Substitution' },
    { typo: 'amoxiclin', intended: 'Amoxicillin', type: 'Omission' },
    { typo: 'asthema', intended: 'Bronchial Asthma', type: 'Insertion' },
    { typo: 'ibuprofn', intended: 'Ibuprofen', type: 'Omission' },
    { typo: 'cephlaxin', intended: 'Cephalexin', type: 'Omission' },
  ];

  return (
    <section className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 p-6 sm:p-10 shadow-2xl">
      {/* Background Glow */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-4xl mx-auto text-center space-y-6">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold tracking-wider uppercase font-mono"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Department of Computer Science • B.Tech Final Year Project</span>
        </motion.div>

        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-tight">
          Efficient Text Search and Retrieval Techniques for{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-500">
            Healthcare Systems
          </span>
        </h1>

        <p className="text-base sm:text-lg text-slate-300 font-medium max-w-2xl mx-auto leading-relaxed">
          Dictionary Query Engine powered by the{' '}
          <strong className="text-amber-300 font-semibold">Minimum Edit Distance (Levenshtein)</strong>{' '}
          Dynamic Programming algorithm. Eliminates zero-result failures when clinicians and patients mistype medical terms.
        </p>

        {/* 3-Step Architectural Pipeline from Slide 2 */}
        <div className="py-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-center text-left">
            {/* Box 1: Input */}
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 flex items-start gap-3">
              <div className="p-2 rounded-lg bg-amber-500/15 text-amber-400 shrink-0">
                <Terminal className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] font-mono uppercase text-amber-400 font-bold tracking-wider">
                  01. Input
                </span>
                <p className="text-xs sm:text-sm font-semibold text-white mt-0.5">
                  Misspelled Health Term
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  e.g., &quot;paracetmol&quot; or &quot;dibetes&quot;
                </p>
              </div>
            </div>

            {/* Box 2: Engine */}
            <div className="p-4 rounded-xl bg-slate-950/80 border border-amber-500/40 ring-1 ring-amber-500/20 flex items-start gap-3 relative">
              <div className="p-2 rounded-lg bg-amber-500 text-slate-950 font-bold shrink-0">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] font-mono uppercase text-amber-400 font-bold tracking-wider">
                  02. Engine
                </span>
                <p className="text-xs sm:text-sm font-semibold text-white mt-0.5">
                  Dictionary + DP Levenshtein
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  O(M×N) bottom-up distance matrix
                </p>
              </div>
            </div>

            {/* Box 3: Output */}
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 flex items-start gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/15 text-emerald-400 shrink-0">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] font-mono uppercase text-emerald-400 font-bold tracking-wider">
                  03. Output
                </span>
                <p className="text-xs sm:text-sm font-semibold text-white mt-0.5">
                  Ranked Suggested Matches
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Closeness score + clinical details
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* 1000 Patients DSA Feature Callout */}
        {onNavigatePatients && (
          <div className="pt-2 flex justify-center">
            <button
              type="button"
              onClick={onNavigatePatients}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold font-mono text-xs shadow-lg shadow-amber-500/20 transition active:scale-95 cursor-pointer"
            >
              <span>Explore 1,000 Patients Dataset (DSA Retrieval &amp; New Admissions)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Quick Clickable Misspellings */}
        <div className="pt-2 flex flex-col items-center gap-2">
          <span className="text-xs font-mono text-slate-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>Click any real-world healthcare typo to test instant retrieval:</span>
          </span>
          <div className="flex flex-wrap justify-center gap-2">
            {sampleTypos.map((item) => (
              <button
                key={item.typo}
                type="button"
                onClick={() => {
                  onSelectQuery(item.typo);
                }}
                className="group flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-amber-500/20 border border-slate-700 hover:border-amber-500/50 text-xs text-slate-200 transition active:scale-95 cursor-pointer"
              >
                <span className="font-mono text-rose-300 font-semibold line-through decoration-rose-500">
                  {item.typo}
                </span>
                <ArrowRight className="w-3 h-3 text-slate-500 group-hover:text-amber-400" />
                <span className="text-amber-300 font-medium">{item.intended}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
