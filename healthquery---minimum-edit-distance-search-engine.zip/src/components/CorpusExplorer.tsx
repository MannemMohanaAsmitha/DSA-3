import { useState } from 'react';
import { BookOpen, Pill, Activity, Stethoscope, Search, ArrowRight, ExternalLink } from 'lucide-react';
import { MEDICAL_CORPUS } from '../data/medicalCorpus.ts';
import { MedicalCategory, MedicalEntry } from '../types/index.ts';

interface CorpusExplorerProps {
  onTestTerm: (term: string) => void;
}

export function CorpusExplorer({ onTestTerm }: CorpusExplorerProps) {
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchFilter, setSearchFilter] = useState<string>('');

  const filteredEntries = MEDICAL_CORPUS.filter((entry) => {
    const matchesCategory = filterCategory === 'all' || entry.category === filterCategory;
    const matchesSearch =
      searchFilter === '' ||
      entry.term.toLowerCase().includes(searchFilter.toLowerCase()) ||
      entry.definition.toLowerCase().includes(searchFilter.toLowerCase()) ||
      entry.commonMisspellings.some((m) => m.toLowerCase().includes(searchFilter.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6" id="medical-corpus-container">
      {/* Header */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-amber-400" />
              <h2 className="text-xl font-bold text-white">
                Structured Healthcare Dictionary Corpus (Slide 4)
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Curated medical dataset covering Drugs, Symptoms, and Diagnoses with verified misspelling sets
            </p>
          </div>

          <span className="px-3 py-1 rounded-full bg-slate-800 text-slate-300 font-mono text-xs">
            {filteredEntries.length} terms displayed
          </span>
        </div>

        {/* Search and Category Filter */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 mt-4">
          <div className="sm:col-span-7 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              id="corpus-filter-input"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              placeholder="Filter corpus by term, indication, or misspelling..."
              className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl text-white text-xs font-mono focus:outline-none"
            />
          </div>

          <div className="sm:col-span-5 flex items-center gap-1.5 overflow-x-auto">
            <button
              type="button"
              onClick={() => setFilterCategory('all')}
              className={`px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition cursor-pointer ${
                filterCategory === 'all'
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              All ({MEDICAL_CORPUS.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterCategory('drug')}
              className={`px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition cursor-pointer ${
                filterCategory === 'drug'
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Drugs ({MEDICAL_CORPUS.filter((c) => c.category === 'drug').length})
            </button>
            <button
              type="button"
              onClick={() => setFilterCategory('symptom')}
              className={`px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition cursor-pointer ${
                filterCategory === 'symptom'
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Symptoms ({MEDICAL_CORPUS.filter((c) => c.category === 'symptom').length})
            </button>
            <button
              type="button"
              onClick={() => setFilterCategory('diagnosis')}
              className={`px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition cursor-pointer ${
                filterCategory === 'diagnosis'
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Diagnoses ({MEDICAL_CORPUS.filter((c) => c.category === 'diagnosis').length})
            </button>
          </div>
        </div>
      </div>

      {/* Corpus Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredEntries.map((item) => (
          <div
            key={item.id}
            className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between space-y-4 shadow-sm"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-wider text-amber-400 font-bold">
                    {item.categoryLabel}
                  </span>
                  <h3 className="text-base font-bold text-white mt-0.5">{item.term}</h3>
                </div>

                <button
                  type="button"
                  onClick={() => onTestTerm(item.commonMisspellings[0] || item.term)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-amber-400 hover:text-slate-950 text-slate-400 transition cursor-pointer text-[11px] font-mono flex items-center gap-1"
                  title={`Test typo "${item.commonMisspellings[0]}" in query engine`}
                >
                  <span>Test</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              <p className="text-xs text-slate-300 mt-2 line-clamp-3 leading-relaxed">
                {item.definition}
              </p>

              <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-2 text-[11px]">
                <div>
                  <span className="text-slate-400 font-medium">Indications:</span>{' '}
                  <span className="text-slate-300">{item.indications}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-medium">Clinical Notes:</span>{' '}
                  <span className="text-slate-300">{item.clinicalNotes}</span>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/60">
              <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">
                Known Misspellings:
              </div>
              <div className="flex flex-wrap gap-1">
                {item.commonMisspellings.map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => onTestTerm(m)}
                    className="px-1.5 py-0.5 rounded bg-slate-950 hover:bg-amber-500/20 hover:text-amber-300 border border-slate-800 text-[10px] font-mono text-slate-400 transition cursor-pointer"
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
