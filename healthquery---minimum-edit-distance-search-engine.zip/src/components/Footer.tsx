import { Activity, ShieldCheck, Heart } from 'lucide-react';
import { TEAM_MEMBERS } from '../data/medicalCorpus.ts';

export function Footer() {
  return (
    <footer className="mt-16 bg-slate-950 border-t border-slate-800 text-slate-400 py-10 px-4 sm:px-6 font-mono text-xs">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-bold flex items-center justify-center">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <div className="text-white font-bold text-sm">
                HealthQuery Engine
              </div>
              <div className="text-[11px] text-slate-400">
                Dictionary Query Engine with Minimum Edit Distance
              </div>
            </div>
          </div>

          <div className="text-[11px] text-slate-400">
            B.Tech Final Year Project • Department of Computer Science
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-slate-400 text-xs">
          <div>
            <span className="text-white font-bold block mb-2 font-sans">
              Algorithm Foundation
            </span>
            <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
              Bottom-up Dynamic Programming matrix formulation for computing Levenshtein Distance with backtracked alignment paths.
            </p>
          </div>

          <div>
            <span className="text-white font-bold block mb-2 font-sans">
              Authors
            </span>
            <ul className="space-y-1 text-[11px]">
              {TEAM_MEMBERS.map((m) => (
                <li key={m.rollNo}>
                  <span className="text-slate-300 font-semibold">{m.name}</span>{' '}
                  <span className="text-slate-500">({m.rollNo})</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <span className="text-white font-bold block mb-2 font-sans">
              Corpus Categories
            </span>
            <ul className="space-y-1 text-[11px] font-sans">
              <li>• Prescription Medications &amp; NSAIDs</li>
              <li>• Clinical Symptoms &amp; Signs</li>
              <li>• Cardiopulmonary &amp; Endocrine Diagnoses</li>
              <li>• Standardized Typographical Error Sets</li>
            </ul>
          </div>

          <div>
            <span className="text-white font-bold block mb-2 font-sans">
              Benchmarked Target
            </span>
            <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
              Empirical testing demonstrates <strong>96% query success rate</strong> compared to 58% baseline exact-match lookups.
            </p>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-400">
          <div>
            © 2026 Department of Computer Science. All rights reserved.
          </div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>Academic Research &amp; Clinical Decision Support Demo</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
