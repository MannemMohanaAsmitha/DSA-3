import { Users, GraduationCap, Award, BookOpen, Code2, Database, Layout, ShieldCheck } from 'lucide-react';
import { TEAM_MEMBERS } from '../data/medicalCorpus.ts';

export function TeamSection() {
  const teamMemberHighlights = [
    {
      ...TEAM_MEMBERS[0],
      icon: Code2,
      bio: 'Responsible for core Dynamic Programming algorithm design, bottom-up matrix formulation, and mathematical verification.',
      contributions: ['Levenshtein Distance Formulation', 'Algorithm Complexity Optimization', 'Edge Case Analysis']
    },
    {
      ...TEAM_MEMBERS[1],
      icon: Database,
      bio: 'Designed the Dictionary Query Engine architecture, typo-tolerance thresholds, and medical term ranking heuristics.',
      contributions: ['Query Retrieval Engine Architecture', 'Similarity Metric & Score Heuristics', 'Real-time Processing Pipeline']
    },
    {
      ...TEAM_MEMBERS[2],
      icon: BookOpen,
      bio: 'Curated and structured the healthcare medical corpus, categorized drug/symptom datasets, and synthesized real-world misspelling corpora.',
      contributions: ['Medical Corpus Curation', 'Misspelling Dataset Modeling', 'Trie / HashMap Schema Structure']
    },
    {
      ...TEAM_MEMBERS[3],
      icon: Layout,
      bio: 'Implemented the interactive clinical query user interface, automated JUnit testing suites, and performance benchmarking.',
      contributions: ['Interactive Clinician Interface', 'JUnit Automated Test Harness', 'Empirical Latency & Accuracy Benchmarks']
    }
  ];

  return (
    <div className="space-y-6" id="team-section-container">
      {/* Header */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-amber-400" />
              <h2 className="text-xl font-bold text-white">Project Authors & Team Members</h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              B.Tech Final Year Project • Department of Computer Science (Slide 01)
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 font-mono text-xs font-semibold">
              B.Tech Computer Science 2026
            </span>
          </div>
        </div>

        {/* Project Credentials Banner */}
        <div className="mt-5 p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-300">
          <div className="flex items-center gap-2 font-mono">
            <GraduationCap className="w-4 h-4 text-amber-400" />
            <strong className="text-white">Project Title:</strong>
            <span>Efficient Text Search and Retrieval Techniques for Healthcare Systems</span>
          </div>
          <div className="flex items-center gap-2 font-mono text-slate-400">
            <Award className="w-4 h-4 text-amber-400" />
            <span>Dictionary Query Engine with Minimum Edit Distance</span>
          </div>
        </div>
      </div>

      {/* Team Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {teamMemberHighlights.map((member) => {
          const Icon = member.icon;
          return (
            <div
              key={member.rollNo}
              className="p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-400/50 transition-all flex flex-col justify-between space-y-4 shadow-md group"
            >
              <div>
                {/* Avatar and Initials */}
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 font-bold font-mono text-base flex items-center justify-center shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform">
                    {member.initials}
                  </div>
                  <div className="p-2 rounded-xl bg-slate-800 text-amber-400">
                    <Icon className="w-4 h-4" />
                  </div>
                </div>

                <h3 className="text-lg font-bold text-white tracking-tight">
                  {member.name}
                </h3>
                <div className="text-xs font-mono font-bold text-amber-400 mt-0.5">
                  Roll No: {member.rollNo}
                </div>
                <div className="text-[11px] text-slate-400 mt-1 font-medium">
                  {member.role}
                </div>

                <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                  {member.bio}
                </p>
              </div>

              {/* Responsibilities list */}
              <div className="pt-3 border-t border-slate-800 space-y-1.5">
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block font-bold">
                  Core Modules:
                </span>
                {member.contributions.map((c) => (
                  <div key={c} className="text-[11px] text-slate-300 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                    <span>{c}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
