import { useState, useMemo, useEffect, useRef } from 'react';
import { Search, SlidersHorizontal, Pill, Activity, Stethoscope, ArrowUpRight, CheckCircle, AlertTriangle, Sparkles, Clock, X, ArrowRight, CheckCircle2, Zap } from 'lucide-react';
import { MEDICAL_CORPUS } from '../data/medicalCorpus.ts';
import { searchMedicalCorpus } from '../utils/levenshtein.ts';
import { MedicalCategory, SearchResult } from '../types/index.ts';
import { detectAndCorrectMedicalMistake } from '../utils/spellingCorrection.ts';

interface QueryEngineDemoProps {
  currentQuery: string;
  setCurrentQuery: (q: string) => void;
  onInspectDP: (s1: string, s2: string) => void;
}

export function QueryEngineDemo({ currentQuery, setCurrentQuery, onInspectDP }: QueryEngineDemoProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [maxDistance, setMaxDistance] = useState<number>(3);
  const [selectedResult, setSelectedResult] = useState<SearchResult | null>(null);

  // Automated spelling correction state
  const [autoCorrectActive, setAutoCorrectActive] = useState<boolean>(true);
  const [autoCorrectionNotice, setAutoCorrectionNotice] = useState<{
    original: string;
    corrected: string;
    distance: number;
    similarity: number;
  } | null>(null);

  // Measure retrieval latency in milliseconds
  const { results, latencyMs } = useMemo(() => {
    const startTime = performance.now();
    const res = searchMedicalCorpus(currentQuery, MEDICAL_CORPUS, {
      maxDistance,
      category: selectedCategory,
    });
    const endTime = performance.now();
    return {
      results: res,
      latencyMs: +(endTime - startTime).toFixed(2),
    };
  }, [currentQuery, selectedCategory, maxDistance]);

  // Live DSA Dictionary Error Mistake Detection
  const detectedMistake = useMemo(() => {
    if (!currentQuery || currentQuery.trim().length < 2) return null;
    const cat = selectedCategory !== 'all' ? (selectedCategory as MedicalCategory) : undefined;
    const res = detectAndCorrectMedicalMistake(currentQuery, cat);
    return res && res.editDistance > 0 ? res : null;
  }, [currentQuery, selectedCategory]);

  const applyAutoCorrection = (mistake: NonNullable<typeof detectedMistake>) => {
    if (!mistake || mistake.editDistance === 0) return;
    setAutoCorrectionNotice({
      original: mistake.originalQuery,
      corrected: mistake.correctedTerm,
      distance: mistake.editDistance,
      similarity: mistake.similarity
    });
    setCurrentQuery(mistake.correctedTerm);
  };

  const handleUndoCorrection = () => {
    if (!autoCorrectionNotice) return;
    const orig = autoCorrectionNotice.original;
    setAutoCorrectionNotice(null);
    setCurrentQuery(orig);
  };

  // Automated debounced correction
  const autoCorrectTimerRef = useRef<NodeJS.Timeout | null>(null);
  useEffect(() => {
    if (!autoCorrectActive || !detectedMistake || detectedMistake.editDistance === 0) return;
    if (detectedMistake.originalQuery.toLowerCase() === detectedMistake.correctedTerm.toLowerCase()) return;

    if (autoCorrectTimerRef.current) clearTimeout(autoCorrectTimerRef.current);
    autoCorrectTimerRef.current = setTimeout(() => {
      applyAutoCorrection(detectedMistake);
    }, 900);

    return () => {
      if (autoCorrectTimerRef.current) clearTimeout(autoCorrectTimerRef.current);
    };
  }, [currentQuery, detectedMistake, autoCorrectActive]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      if (detectedMistake && detectedMistake.editDistance > 0) {
        e.preventDefault();
        applyAutoCorrection(detectedMistake);
      }
    }
  };

  const handleBlur = () => {
    if (autoCorrectActive && detectedMistake && detectedMistake.editDistance > 0) {
      applyAutoCorrection(detectedMistake);
    }
  };

  useEffect(() => {
    if (results.length > 0 && !selectedResult) {
      setSelectedResult(results[0]);
    } else if (results.length === 0) {
      setSelectedResult(null);
    }
  }, [results, selectedResult]);

  const categories: { id: string; label: string; icon: typeof Pill }[] = [
    { id: 'all', label: 'All Categories', icon: Sparkles },
    { id: 'drug', label: 'Drugs / Medications', icon: Pill },
    { id: 'symptom', label: 'Symptoms & Signs', icon: Activity },
    { id: 'diagnosis', label: 'Diagnoses & Diseases', icon: Stethoscope },
  ];

  const quickExamples = [
    'paracetmol',
    'dibetes',
    'amoxiclin',
    'asthema',
    'hypertnnsion',
    'ibuprofn',
    'dispnea',
    'cephlaxin',
    'atorvastin',
    'nausia',
  ];

  return (
    <div className="space-y-6" id="live-query-engine-container">
      {/* Search Header and Input */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-800">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Search className="w-5 h-5 text-amber-400" />
              <span>Interactive Healthcare Query Engine</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Evaluates Minimum Edit Distance (Levenshtein) across {MEDICAL_CORPUS.length} curated clinical terms
            </p>
          </div>

          {/* Real-time stats & Auto-Correct Toggle */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => setAutoCorrectActive(!autoCorrectActive)}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-semibold flex items-center gap-1.5 transition cursor-pointer border ${
                autoCorrectActive
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}
              title="Toggle automatic typo correction on search input"
            >
              <Zap className={`w-3.5 h-3.5 ${autoCorrectActive ? 'text-emerald-400' : ''}`} />
              <span>Auto-Correct: {autoCorrectActive ? 'ON' : 'OFF'}</span>
            </button>

            <div className="flex items-center gap-4 text-xs font-mono text-slate-400 bg-slate-950/80 px-3.5 py-2 rounded-xl border border-slate-800 self-start md:self-auto">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>{latencyMs} ms</span>
              </div>
              <span className="text-slate-700">•</span>
              <div>
                <span className="text-amber-400 font-bold">{results.length}</span> matches found
              </div>
              <span className="text-slate-700">•</span>
              <div>
                Corpus: <span className="text-slate-200">{MEDICAL_CORPUS.length}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Input Bar */}
        <div className="mt-5 space-y-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-amber-400">
              <Search className="w-5 h-5" />
            </div>
            <input
              type="text"
              id="healthcare-search-input"
              value={currentQuery}
              onChange={(e) => setCurrentQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              onBlur={handleBlur}
              placeholder="Type medical term with or without typos (e.g. paracetmol, dibetes, amoxiclin)..."
              className="w-full pl-12 pr-10 py-3.5 bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl text-white placeholder-slate-500 font-mono text-sm sm:text-base transition focus:outline-none focus:ring-2 focus:ring-amber-400/20"
            />
            {currentQuery && (
              <button
                type="button"
                id="clear-search-btn"
                onClick={() => {
                  setCurrentQuery('');
                  setAutoCorrectionNotice(null);
                }}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-white cursor-pointer"
                title="Clear query"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Auto-Correction Notice Banner */}
          {autoCorrectionNotice && (
            <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 flex items-center justify-between gap-3 text-xs animate-in fade-in">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <span>
                    Automatically corrected:{' '}
                    <span className="line-through text-rose-300 font-mono font-semibold">&quot;{autoCorrectionNotice.original}&quot;</span>
                    {' '}➔{' '}
                    <strong className="text-white font-mono">&quot;{autoCorrectionNotice.corrected}&quot;</strong>
                  </span>
                  <span className="ml-2 text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Levenshtein Distance: {autoCorrectionNotice.distance} • {autoCorrectionNotice.similarity}% Match
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleUndoCorrection}
                  className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-mono text-[11px] transition cursor-pointer"
                >
                  Undo
                </button>
                <button
                  type="button"
                  onClick={() => setAutoCorrectionNotice(null)}
                  className="p-1 text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* Real-time Dictionary Mistake Detection & Auto-Correction Card */}
          {detectedMistake && (
            <div className="p-4 rounded-xl bg-gradient-to-r from-amber-500/15 via-slate-900 to-amber-500/10 border border-amber-500/40 text-amber-200 space-y-3 animate-in fade-in slide-in-from-top-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-amber-500/20">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                  <div>
                    <span className="font-bold text-sm text-white">
                      Spelling Error Detected: &quot;{detectedMistake.originalQuery}&quot;
                    </span>
                    <span className="ml-2 text-xs font-mono px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                      {detectedMistake.errorType} Error (Edit Distance: {detectedMistake.editDistance})
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-emerald-400 font-semibold">
                    {detectedMistake.similarity}% Similarity Match
                  </span>
                </div>
              </div>

              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                <div className="space-y-1">
                  <div className="text-slate-300">
                    {detectedMistake.explanation}
                  </div>
                  <div className="text-slate-200">
                    Dictionary Query Engine Auto-Correction:{' '}
                    <strong className="text-amber-300 text-sm font-semibold underline decoration-amber-400 underline-offset-4">
                      {detectedMistake.correctedTerm}
                    </strong>{' '}
                    <span className="text-slate-400 font-mono text-[11px]">({detectedMistake.categoryLabel})</span>
                    {autoCorrectActive && (
                      <span className="ml-2 text-[10px] text-emerald-400 font-mono">
                        (Auto-correcting automatically...)
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => applyAutoCorrection(detectedMistake)}
                    className="px-3.5 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Auto-Correct Now: &quot;{detectedMistake.correctedTerm}&quot;</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onInspectDP(detectedMistake.originalQuery, detectedMistake.correctedTerm)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-mono text-xs border border-amber-500/30 flex items-center gap-1 transition cursor-pointer"
                  >
                    <span>Inspect 2D DP Matrix</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Quick Click Badges */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="text-slate-400 font-mono mr-1">Quick Try:</span>
            {quickExamples.map((ex) => (
              <button
                key={ex}
                type="button"
                onClick={() => setCurrentQuery(ex)}
                className={`px-2.5 py-1 rounded-md font-mono text-xs transition cursor-pointer ${
                  currentQuery.toLowerCase() === ex
                    ? 'bg-amber-400 text-slate-950 font-bold'
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300'
                }`}
              >
                {ex}
              </button>
            ))}
          </div>

          {/* Controls: Category Filter & Max Distance Slider */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-slate-800/80">
            {/* Category Pills */}
            <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Category Filter">
              {categories.map((cat) => {
                const Icon = cat.icon;
                const isSelected = selectedCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/20 border border-amber-400 text-amber-300'
                        : 'bg-slate-800/50 hover:bg-slate-800 text-slate-400 border border-transparent'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{cat.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Threshold Slider */}
            <div className="flex items-center gap-3 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-xs text-slate-300">
              <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
              <label htmlFor="max-dist-slider" className="font-mono text-[11px]">
                Max Edit Distance Threshold:
              </label>
              <input
                id="max-dist-slider"
                type="range"
                min={1}
                max={4}
                step={1}
                value={maxDistance}
                onChange={(e) => setMaxDistance(Number(e.target.value))}
                className="w-20 accent-amber-400 cursor-pointer"
              />
              <span className="font-mono font-bold text-amber-400 px-1.5 py-0.5 rounded bg-slate-800">
                {maxDistance}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Results and Detail Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Ranked Results List */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1 font-mono">
            <span>Ranked Candidates by Minimum Edit Distance</span>
            <span>Sorted: Distance ASC, Similarity DESC</span>
          </div>

          {currentQuery.trim() === '' ? (
            <div className="bg-slate-900/60 rounded-xl border border-slate-800/80 p-8 text-center space-y-3">
              <Search className="w-8 h-8 text-slate-600 mx-auto" />
              <h3 className="text-sm font-semibold text-slate-300">Ready for Query</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Type any medical term, symptom, or medication above (or pick one of the quick try buttons) to see the Levenshtein algorithm in action.
              </p>
            </div>
          ) : results.length === 0 ? (
            <div className="bg-slate-900/80 rounded-xl border border-rose-900/50 p-6 text-center space-y-3">
              <AlertTriangle className="w-8 h-8 text-rose-400 mx-auto" />
              <h3 className="text-sm font-semibold text-rose-200">No candidates within threshold</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                No medical terms matched &quot;{currentQuery}&quot; with an edit distance of ≤ {maxDistance}. Try increasing the tolerance slider or correcting obvious keystrokes.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {results.map((res, index) => {
                const isSelected = selectedResult?.entry.id === res.entry.id;
                const isExact = res.exactMatch;
                return (
                  <div
                    key={res.entry.id}
                    id={`result-card-${res.entry.id}`}
                    onClick={() => setSelectedResult(res)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-slate-850 bg-slate-900 border-amber-400/80 ring-1 ring-amber-400/40 shadow-md'
                        : 'bg-slate-900/80 hover:bg-slate-900 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono text-xs font-bold text-slate-500">
                            #{index + 1}
                          </span>
                          <h4 className="text-base font-bold text-white tracking-tight">
                            {res.entry.term}
                          </h4>
                          <span
                            className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded font-semibold ${
                              res.entry.category === 'drug'
                                ? 'bg-blue-500/15 text-blue-300 border border-blue-500/30'
                                : res.entry.category === 'symptom'
                                ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                                : 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                            }`}
                          >
                            {res.entry.category}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1 line-clamp-1">
                          {res.entry.definition}
                        </p>
                      </div>

                      {/* Distance & Similarity Badge */}
                      <div className="text-right shrink-0">
                        <div className="flex items-center gap-1.5 justify-end">
                          {isExact ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-mono font-bold">
                              <CheckCircle className="w-3 h-3" /> Exact
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[11px] font-mono font-bold">
                              Dist: {res.distance}
                            </span>
                          )}
                        </div>
                        <div className="text-xs font-mono text-slate-400 mt-1">
                          {res.similarity}% match
                        </div>
                      </div>
                    </div>

                    {/* Progress similarity bar */}
                    <div className="mt-3 w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 ${
                          isExact
                            ? 'bg-emerald-400'
                            : res.similarity >= 75
                            ? 'bg-amber-400'
                            : 'bg-orange-500'
                        }`}
                        style={{ width: `${res.similarity}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Selected Term Detail & Levenshtein Breakdown */}
        <div className="lg:col-span-5">
          {selectedResult ? (
            <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-5 sticky top-24">
              <div className="flex items-start justify-between gap-2 pb-4 border-b border-slate-800">
                <div>
                  <span className="text-[11px] uppercase tracking-wider font-mono text-amber-400 font-bold">
                    {selectedResult.entry.categoryLabel}
                  </span>
                  <h3 className="text-xl font-extrabold text-white mt-0.5">
                    {selectedResult.entry.term}
                  </h3>
                </div>

                <button
                  type="button"
                  id="inspect-dp-matrix-btn"
                  onClick={() => onInspectDP(currentQuery, selectedResult.entry.term)}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-semibold transition active:scale-95 cursor-pointer shadow-md shadow-amber-500/20"
                >
                  <span>Inspect DP Matrix</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Match Diagnostics */}
              <div className="bg-slate-950/80 rounded-xl p-4 border border-slate-800 font-mono text-xs space-y-2">
                <div className="text-slate-400 font-semibold text-[11px] uppercase tracking-wider">
                  Levenshtein Metrics
                </div>
                <div className="grid grid-cols-2 gap-2 text-slate-300">
                  <div>
                    User Query: <span className="text-rose-300 font-bold">{currentQuery}</span>
                  </div>
                  <div>
                    Target: <span className="text-amber-300 font-bold">{selectedResult.entry.term}</span>
                  </div>
                  <div>
                    Edit Distance:{' '}
                    <span className="text-white font-bold">{selectedResult.distance}</span>
                  </div>
                  <div>
                    Similarity Score:{' '}
                    <span className="text-emerald-400 font-bold">
                      {selectedResult.similarity}%
                    </span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Deletions: {selectedResult.operations.deletions}</span>
                  <span>Insertions: {selectedResult.operations.insertions}</span>
                  <span>Substitutions: {selectedResult.operations.substitutions}</span>
                </div>
              </div>

              {/* Clinical Information */}
              <div className="space-y-3 text-xs">
                <div>
                  <h5 className="font-semibold text-slate-300 uppercase tracking-wider text-[11px]">
                    Clinical Definition
                  </h5>
                  <p className="text-slate-400 mt-1 leading-relaxed">
                    {selectedResult.entry.definition}
                  </p>
                </div>

                <div>
                  <h5 className="font-semibold text-slate-300 uppercase tracking-wider text-[11px]">
                    Primary Indications / Triggers
                  </h5>
                  <p className="text-slate-400 mt-1 leading-relaxed">
                    {selectedResult.entry.indications}
                  </p>
                </div>

                <div>
                  <h5 className="font-semibold text-slate-300 uppercase tracking-wider text-[11px]">
                    Prescription / Clinical Notes
                  </h5>
                  <p className="text-slate-400 mt-1 leading-relaxed">
                    {selectedResult.entry.clinicalNotes}
                  </p>
                </div>

                <div>
                  <h5 className="font-semibold text-slate-300 uppercase tracking-wider text-[11px]">
                    Recognized Clinical Misspellings
                  </h5>
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {selectedResult.entry.commonMisspellings.map((m) => (
                      <span
                        key={m}
                        className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono text-[11px]"
                      >
                        {m}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-900/50 rounded-2xl border border-slate-800/80 p-8 text-center text-slate-500 text-xs">
              Select a search result candidate on the left to examine detailed medical diagnostics and edit distance operations.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
