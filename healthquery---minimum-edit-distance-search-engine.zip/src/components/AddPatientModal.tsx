import { useState, useMemo, useEffect, useRef } from 'react';
import { X, UserPlus, Pill, Stethoscope, Plus, Trash2, CheckCircle2, AlertTriangle, Sparkles, Building, Phone, User, Zap } from 'lucide-react';
import { Patient, PatientMedication } from '../types/index.ts';
import { MEDICAL_CORPUS } from '../data/medicalCorpus.ts';
import {
  detectAndCorrectMedicalMistake,
  autoCorrectDiagnosis,
  autoCorrectMedication,
  autoCorrectSymptoms,
  SpellingMistakeDetection
} from '../utils/spellingCorrection.ts';

interface AddPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddPatient: (patient: Patient) => void;
  nextId: string;
}

export function AddPatientModal({ isOpen, onClose, onAddPatient, nextId }: AddPatientModalProps) {
  const [name, setName] = useState('');
  const [age, setAge] = useState<number>(42);
  const [gender, setGender] = useState<Patient['gender']>('Female');
  const [bloodGroup, setBloodGroup] = useState('B+');
  const [contact, setContact] = useState('+91 9848022338');
  const [diagnosis, setDiagnosis] = useState('');
  const [symptomsInput, setSymptomsInput] = useState('');
  const [department, setDepartment] = useState('Endocrinology');
  const [attendingPhysician, setAttendingPhysician] = useState('Dr. S. K. Gupta, MD');
  const [status, setStatus] = useState<Patient['status']>('Inpatient');
  const [notes, setNotes] = useState('Admitted with acute symptoms. Vital signs monitored.');
  const [medications, setMedications] = useState<PatientMedication[]>([
    { drugName: '', dosage: '500mg', frequency: 'Twice daily after meals' }
  ]);
  const [error, setError] = useState<string | null>(null);

  // Automated spelling correction state
  const [autoCorrectEnabled, setAutoCorrectEnabled] = useState<boolean>(true);
  const [recentAutoCorrections, setRecentAutoCorrections] = useState<
    { id: string; field: string; from: string; to: string; distance: number }[]
  >([]);

  // Live DSA Dictionary Spell Check on Diagnosis
  const diagnosisMistake = useMemo(() => {
    if (!diagnosis || diagnosis.trim().length < 3) return null;
    const res = detectAndCorrectMedicalMistake(diagnosis, 'diagnosis');
    return res && res.editDistance > 0 ? res : null;
  }, [diagnosis]);

  // Live DSA Dictionary Spell Check on Medications
  const medicationMistakes = useMemo(() => {
    return medications.map((med) => {
      if (!med.drugName || med.drugName.trim().length < 3) return null;
      const res = detectAndCorrectMedicalMistake(med.drugName, 'drug');
      return res && res.editDistance > 0 ? res : null;
    });
  }, [medications]);

  // Helper to record an automated correction
  const recordCorrection = (field: string, from: string, to: string, distance: number) => {
    setRecentAutoCorrections((prev) => [
      { id: `${Date.now()}-${Math.random()}`, field, from, to, distance },
      ...prev.slice(0, 4)
    ]);
  };

  // Automated Diagnosis Correction on Blur
  const handleDiagnosisBlur = () => {
    if (!autoCorrectEnabled || !diagnosis) return;
    const res = autoCorrectDiagnosis(diagnosis);
    if (res.wasCorrected && res.details) {
      setDiagnosis(res.corrected);
      recordCorrection('Diagnosis', res.original, res.corrected, res.details.editDistance);

      // Auto-assign appropriate hospital department
      if (res.corrected.includes('Diabetes') || res.corrected.includes('Thyroid') || res.corrected.includes('Hypothyroidism')) {
        setDepartment('Endocrinology');
      } else if (res.corrected.includes('Hypertension') || res.corrected.includes('Atherosclerosis')) {
        setDepartment('Cardiology');
      } else if (res.corrected.includes('Asthma') || res.corrected.includes('Pneumonia')) {
        setDepartment('Pulmonology');
      } else if (res.corrected.includes('Osteoarthritis')) {
        setDepartment('Orthopedics');
      } else if (res.corrected.includes('Gastroenteritis')) {
        setDepartment('Gastroenterology');
      } else if (res.corrected.includes('Migraine') || res.corrected.includes('Neuropathy') || res.corrected.includes('Multiple Sclerosis')) {
        setDepartment('Neurology');
      } else if (res.corrected.includes('Tuberculosis')) {
        setDepartment('Infectious Disease');
      }
    }
  };

  // Debounced live auto-correction while typing diagnosis
  const diagTimerRef = useRef<NodeJS.Timeout | null>(null);
  useEffect(() => {
    if (!autoCorrectEnabled || !diagnosis || diagnosis.trim().length < 4) return;
    if (diagTimerRef.current) clearTimeout(diagTimerRef.current);

    diagTimerRef.current = setTimeout(() => {
      const res = autoCorrectDiagnosis(diagnosis);
      if (res.wasCorrected && res.details && res.details.editDistance > 0) {
        setDiagnosis(res.corrected);
        recordCorrection('Diagnosis', res.original, res.corrected, res.details.editDistance);
      }
    }, 1200);

    return () => {
      if (diagTimerRef.current) clearTimeout(diagTimerRef.current);
    };
  }, [diagnosis, autoCorrectEnabled]);

  // Automated Medication Correction on Blur
  const handleMedBlur = (index: number) => {
    if (!autoCorrectEnabled) return;
    const currentDrug = medications[index]?.drugName;
    if (!currentDrug || currentDrug.trim().length < 3) return;

    const res = autoCorrectMedication(currentDrug);
    if (res.wasCorrected && res.details) {
      const updated = [...medications];
      updated[index].drugName = res.corrected;
      setMedications(updated);
      recordCorrection(`Medication #${index + 1}`, res.original, res.corrected, res.details.editDistance);
    }
  };

  // Automated Symptoms Correction on Blur
  const handleSymptomsBlur = () => {
    if (!autoCorrectEnabled || !symptomsInput.trim()) return;
    const res = autoCorrectSymptoms(symptomsInput);
    if (res.correctedCount > 0) {
      setSymptomsInput(res.corrected);
      res.corrections.forEach((c) => {
        recordCorrection('Symptom', c.from, c.to, 1);
      });
    }
  };

  if (!isOpen) return null;

  const handleAddMedication = () => {
    setMedications([...medications, { drugName: '', dosage: '500mg', frequency: 'Once daily' }]);
  };

  const handleRemoveMedication = (index: number) => {
    if (medications.length <= 1) return;
    setMedications(medications.filter((_, idx) => idx !== index));
  };

  const handleMedChange = (index: number, field: keyof PatientMedication, val: string) => {
    const updated = [...medications];
    updated[index][field] = val;
    setMedications(updated);
  };

  const handleApplyDiagnosisCorrection = () => {
    if (!diagnosisMistake) return;
    setDiagnosis(diagnosisMistake.correctedTerm);
    recordCorrection('Diagnosis', diagnosisMistake.originalQuery, diagnosisMistake.correctedTerm, diagnosisMistake.editDistance);
    if (diagnosisMistake.matchedEntry.categoryLabel) {
      if (diagnosisMistake.correctedTerm.includes('Diabetes') || diagnosisMistake.correctedTerm.includes('Thyroid')) {
        setDepartment('Endocrinology');
      } else if (diagnosisMistake.correctedTerm.includes('Hypertension') || diagnosisMistake.correctedTerm.includes('Atherosclerosis')) {
        setDepartment('Cardiology');
      } else if (diagnosisMistake.correctedTerm.includes('Asthma') || diagnosisMistake.correctedTerm.includes('Pneumonia')) {
        setDepartment('Pulmonology');
      }
    }
  };

  const handleApplyMedCorrection = (index: number) => {
    const mistake = medicationMistakes[index];
    if (!mistake) return;
    const updated = [...medications];
    updated[index].drugName = mistake.correctedTerm;
    setMedications(updated);
    recordCorrection(`Medication #${index + 1}`, mistake.originalQuery, mistake.correctedTerm, mistake.editDistance);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter patient full name');
      return;
    }
    if (!diagnosis.trim()) {
      setError('Please enter clinical diagnosis or disease');
      return;
    }

    // Auto-correct diagnosis if still misspelled
    let finalDiagnosis = diagnosis.trim();
    if (autoCorrectEnabled) {
      const diagRes = autoCorrectDiagnosis(finalDiagnosis);
      if (diagRes.wasCorrected) {
        finalDiagnosis = diagRes.corrected;
      }
    }

    // Auto-correct symptoms
    const symptomsList = symptomsInput
      .split(',')
      .map((s) => {
        const trimmed = s.trim();
        if (!autoCorrectEnabled || !trimmed) return trimmed;
        const res = detectAndCorrectMedicalMistake(trimmed, 'symptom');
        return res && res.editDistance > 0 ? res.correctedTerm : trimmed;
      })
      .filter(Boolean);

    // Auto-correct medications
    const validMeds = medications
      .filter((m) => m.drugName.trim())
      .map((m) => {
        let drugName = m.drugName.trim();
        if (autoCorrectEnabled) {
          const medRes = autoCorrectMedication(drugName);
          if (medRes.wasCorrected) {
            drugName = medRes.corrected;
          }
        }
        return {
          drugName,
          dosage: m.dosage.trim() || 'Standard Dose',
          frequency: m.frequency.trim() || 'Once daily'
        };
      });

    const newPatient: Patient = {
      id: nextId,
      name: name.trim(),
      age: Number(age) || 30,
      gender,
      bloodGroup,
      contact: contact.trim() || '+91 9876543210',
      admissionDate: new Date().toISOString().split('T')[0],
      diagnosis: finalDiagnosis,
      symptoms: symptomsList.length > 0 ? symptomsList : ['Fatigue', 'General Malaise'],
      medications: validMeds.length > 0 ? validMeds : [{ drugName: 'Paracetamol', dosage: '500mg', frequency: 'As needed' }],
      attendingPhysician: attendingPhysician.trim() || 'Dr. Medical Officer, MD',
      department: department.trim() || 'General Medicine',
      status,
      notes: notes.trim() || `Admitted with ${finalDiagnosis}. Monitored under ${department.trim()}.`
    };

    onAddPatient(newPatient);
    onClose();
  };


  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 bg-slate-900/90 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 font-bold flex items-center justify-center shadow-lg shadow-amber-500/20">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white tracking-tight">
                  Add Clinical Patient Record
                </h3>
                <span className="px-2 py-0.5 rounded font-mono font-bold text-xs bg-amber-400/20 text-amber-300 border border-amber-400/30">
                  {nextId}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Personal details, diseases &amp; diagnosis, medications with DSA Dictionary Spell Check
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto text-xs font-mono">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* SECTION 1: PERSONAL DETAILS */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider pb-1 border-b border-slate-800">
              <User className="w-4 h-4" />
              <span>1. Patient Personal Details</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <div className="sm:col-span-8">
                <label className="block text-[11px] text-slate-400 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Aravind Reddy, Priya Chowdary"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none font-sans"
                />
              </div>

              <div className="sm:col-span-4">
                <label className="block text-[11px] text-slate-400 mb-1">
                  Age *
                </label>
                <input
                  type="number"
                  min={1}
                  max={120}
                  required
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div className="sm:col-span-4">
                <label className="block text-[11px] text-slate-400 mb-1">
                  Gender
                </label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as Patient['gender'])}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none cursor-pointer"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div className="sm:col-span-4">
                <label className="block text-[11px] text-slate-400 mb-1">
                  Blood Group
                </label>
                <select
                  value={bloodGroup}
                  onChange={(e) => setBloodGroup(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none cursor-pointer"
                >
                  {['O+', 'B+', 'A+', 'AB+', 'O-', 'B-', 'A-', 'AB-'].map((bg) => (
                    <option key={bg} value={bg}>{bg}</option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-4">
                <label className="block text-[11px] text-slate-400 mb-1">
                  Contact Number
                </label>
                <input
                  type="text"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  placeholder="+91 9848011223"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none font-mono"
                />
              </div>
            </div>
          </div>

          {/* SECTION 2: DISEASES & DIAGNOSIS (WITH LIVE DICTIONARY ERROR MISTAKE DETECTION) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-slate-800">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
                <Stethoscope className="w-4 h-4" />
                <span>2. Diseases &amp; Clinical Diagnosis</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setAutoCorrectEnabled(!autoCorrectEnabled)}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold flex items-center gap-1 transition cursor-pointer border ${
                    autoCorrectEnabled
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                  title="Toggle automatic typo correction"
                >
                  <Zap className={`w-3 h-3 ${autoCorrectEnabled ? 'text-emerald-400' : ''}`} />
                  <span>Auto-Correct: {autoCorrectEnabled ? 'ON' : 'OFF'}</span>
                </button>
                <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
                  <Sparkles className="w-3 h-3" />
                  <span>Dictionary Active</span>
                </span>
              </div>
            </div>

            {/* Recent Automated Corrections Banner */}
            {recentAutoCorrections.length > 0 && (
              <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-200 text-xs space-y-1 animate-in fade-in">
                <div className="flex items-center justify-between font-bold text-emerald-300 text-[11px]">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Automated Spelling Corrections Applied</span>
                  </span>
                  <span className="text-[10px] text-emerald-400/80 font-mono">DSA Levenshtein Engine</span>
                </div>
                {recentAutoCorrections.slice(0, 3).map((item) => (
                  <div key={item.id} className="flex items-center justify-between text-[11px] bg-slate-900/80 px-2 py-1 rounded border border-emerald-500/20">
                    <div>
                      <span className="text-slate-400 font-medium">{item.field}:</span>{' '}
                      <span className="line-through text-rose-300 font-mono">{item.from}</span>
                      <span className="text-slate-400 mx-1.5">➔</span>
                      <span className="text-emerald-300 font-bold font-mono">{item.to}</span>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400/70">Edit Dist: {item.distance}</span>
                  </div>
                ))}
              </div>
            )}

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">
                Primary Diagnosis / Disease * (Typing errors like &quot;dibetes&quot; or &quot;hypertnnsion&quot; are automatically corrected)
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={diagnosis}
                  onChange={(e) => setDiagnosis(e.target.value)}
                  onBlur={handleDiagnosisBlur}
                  placeholder="e.g. Diabetes Mellitus, Hypertension, Bronchial Asthma"
                  className={`w-full px-3 py-2.5 bg-slate-950 border rounded-lg text-white text-xs focus:outline-none transition ${
                    diagnosisMistake
                      ? 'border-amber-500/80 ring-1 ring-amber-500/30'
                      : 'border-slate-700 focus:border-amber-400'
                  }`}
                />
              </div>

              {/* Real-Time Dictionary Mistake Correction Banner */}
              {diagnosisMistake && (
                <div className="mt-2 p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 animate-in fade-in">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-bold text-xs text-amber-300">
                        Spelling Mistake Detected: &quot;{diagnosisMistake.originalQuery}&quot; ({diagnosisMistake.errorType}, Distance: {diagnosisMistake.editDistance})
                      </div>
                      <div className="text-[11px] text-slate-300">
                        Auto-correcting to: <strong className="text-white underline">{diagnosisMistake.correctedTerm}</strong> (Click or blur field to complete)
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleApplyDiagnosisCorrection}
                    className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1 shrink-0 self-start sm:self-auto cursor-pointer shadow"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Auto-Correct Now</span>
                  </button>
                </div>
              )}
            </div>

            {/* Quick Diagnostic Suggestions */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[11px]">
              <span className="text-slate-500">Quick select:</span>
              {[
                'Diabetes Mellitus',
                'Hypertension',
                'Bronchial Asthma',
                'Community-Acquired Pneumonia',
                'Osteoarthritis',
                'Atherosclerosis & CAD'
              ].map((term) => (
                <button
                  key={term}
                  type="button"
                  onClick={() => setDiagnosis(term)}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer text-[10px]"
                >
                  {term}
                </button>
              ))}
            </div>

            {/* Symptoms Input */}
            <div className="pt-2">
              <label className="block text-[11px] text-slate-400 mb-1">
                Reported Clinical Symptoms (Comma-separated, automatically spell-checked)
              </label>
              <input
                type="text"
                value={symptomsInput}
                onChange={(e) => setSymptomsInput(e.target.value)}
                onBlur={handleSymptomsBlur}
                placeholder="e.g. Fatigue, Paresthesia, Dyspnea, Headache"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          {/* SECTION 3: PRESCRIBED MEDICATIONS (WITH LIVE DICTIONARY ERROR MISTAKE DETECTION) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-slate-800">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
                <Pill className="w-4 h-4" />
                <span>3. Prescribed Medications &amp; Posology</span>
              </div>
              <button
                type="button"
                onClick={handleAddMedication}
                className="flex items-center gap-1 text-xs text-amber-400 hover:text-amber-300 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Drug</span>
              </button>
            </div>

            <div className="space-y-3">
              {medications.map((med, idx) => {
                const mistake = medicationMistakes[idx];
                return (
                  <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                      <div className="sm:col-span-5">
                        <label className="block text-[10px] text-slate-500 mb-0.5">Drug Name (e.g. paracetmol, metformin, amoxiclin)</label>
                        <input
                          type="text"
                          value={med.drugName}
                          onChange={(e) => handleMedChange(idx, 'drugName', e.target.value)}
                          onBlur={() => handleMedBlur(idx)}
                          placeholder="e.g. Paracetamol"
                          className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded text-white text-xs focus:border-amber-400 focus:outline-none"
                        />
                      </div>

                      <div className="sm:col-span-3">
                        <label className="block text-[10px] text-slate-500 mb-0.5">Dosage</label>
                        <input
                          type="text"
                          value={med.dosage}
                          onChange={(e) => handleMedChange(idx, 'dosage', e.target.value)}
                          placeholder="e.g. 500mg, 10mg"
                          className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded text-white text-xs focus:border-amber-400 focus:outline-none"
                        />
                      </div>

                      <div className="sm:col-span-3">
                        <label className="block text-[10px] text-slate-500 mb-0.5">Frequency</label>
                        <input
                          type="text"
                          value={med.frequency}
                          onChange={(e) => handleMedChange(idx, 'frequency', e.target.value)}
                          placeholder="e.g. Twice daily"
                          className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded text-white text-xs focus:border-amber-400 focus:outline-none"
                        />
                      </div>

                      <div className="sm:col-span-1 flex items-end justify-center pb-1">
                        {medications.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveMedication(idx)}
                            className="p-1.5 rounded hover:bg-slate-800 text-rose-400 hover:text-rose-300 transition cursor-pointer"
                            title="Remove drug"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Live Medication Typo Banner */}
                    {mistake && (
                      <div className="p-2 rounded bg-amber-500/10 border border-amber-500/30 text-amber-200 flex items-center justify-between text-[11px]">
                        <span>
                          ⚠️ Typo in Drug: &quot;{mistake.originalQuery}&quot; ➔ Auto-correcting to <strong>{mistake.correctedTerm}</strong>
                        </span>
                        <button
                          type="button"
                          onClick={() => handleApplyMedCorrection(idx)}
                          className="px-2 py-0.5 rounded bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-[10px] transition cursor-pointer"
                        >
                          Auto-Correct Now
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* SECTION 4: DEPARTMENT, PHYSICIAN & ADMISSION STATUS */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider pb-1 border-b border-slate-800">
              <Building className="w-4 h-4" />
              <span>4. Hospital Department &amp; Care Status</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  Department
                </label>
                <select
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none cursor-pointer"
                >
                  <option value="Endocrinology">Endocrinology</option>
                  <option value="Cardiology">Cardiology</option>
                  <option value="Pulmonology">Pulmonology</option>
                  <option value="Neurology">Neurology</option>
                  <option value="Orthopedics">Orthopedics</option>
                  <option value="Gastroenterology">Gastroenterology</option>
                  <option value="Nephrology">Nephrology</option>
                  <option value="Rheumatology">Rheumatology</option>
                  <option value="Infectious Disease">Infectious Disease</option>
                  <option value="ENT & Allergy">ENT & Allergy</option>
                  <option value="General Medicine">General Medicine</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  Care Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as Patient['status'])}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none cursor-pointer"
                >
                  <option value="Inpatient">Inpatient</option>
                  <option value="Critical">Critical (ICU)</option>
                  <option value="Outpatient">Outpatient</option>
                  <option value="Discharged">Discharged</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  Attending Physician
                </label>
                <input
                  type="text"
                  value={attendingPhysician}
                  onChange={(e) => setAttendingPhysician(e.target.value)}
                  placeholder="Dr. S. K. Gupta, MD"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">
                Clinical Notes / Observations
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs focus:border-amber-400 focus:outline-none font-sans"
              />
            </div>
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Save &amp; Index Patient</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
