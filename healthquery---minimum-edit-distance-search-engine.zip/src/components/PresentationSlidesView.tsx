import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Presentation, Maximize2, Minimize2, CheckCircle2, AlertCircle, Cpu, BarChart3, Users, HelpCircle } from 'lucide-react';
import { TEAM_MEMBERS } from '../data/medicalCorpus.ts';

export function PresentationSlidesView() {
  const [currentSlide, setCurrentSlide] = useState<number>(1);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  const totalSlides = 7;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') {
        setCurrentSlide((prev) => Math.min(totalSlides, prev + 1));
      } else if (e.key === 'ArrowLeft') {
        setCurrentSlide((prev) => Math.max(1, prev - 1));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  return (
    <div
      id="presentation-slide-deck"
      className={`space-y-4 ${
        isFullscreen ? 'fixed inset-0 z-50 bg-slate-950 p-6 overflow-y-auto flex flex-col justify-between' : ''
      }`}
    >
      {/* Slide Navigation Header */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 px-5 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Presentation className="w-5 h-5 text-amber-400" />
          <h2 className="text-sm sm:text-base font-bold text-white">
            Project Deck: Slide {currentSlide} of {totalSlides}
          </h2>
        </div>

        {/* Slide Indicators & Navigation */}
        <div className="flex items-center gap-2">
          <div className="flex gap-1">
            {Array.from({ length: totalSlides }).map((_, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setCurrentSlide(i + 1)}
                className={`w-6 h-6 rounded text-[11px] font-mono font-bold transition cursor-pointer ${
                  currentSlide === i + 1
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-400'
                }`}
              >
                0{i + 1}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 ml-2">
            <button
              type="button"
              onClick={() => setCurrentSlide((prev) => Math.max(1, prev - 1))}
              disabled={currentSlide === 1}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-white cursor-pointer"
              title="Previous Slide (Left Arrow)"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setCurrentSlide((prev) => Math.min(totalSlides, prev + 1))}
              disabled={currentSlide === totalSlides}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-white cursor-pointer"
              title="Next Slide (Right Arrow)"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={toggleFullscreen}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer ml-1"
              title="Toggle Fullscreen"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Slide Canvas: Faithful high-fidelity render of each slide */}
      <div className="aspect-[16/9] min-h-[480px] w-full rounded-2xl bg-[#0b1728] border border-slate-700/80 p-8 sm:p-12 text-slate-100 flex flex-col justify-between shadow-2xl relative overflow-hidden">
        {/* Slide 1: Introduction */}
        {currentSlide === 1 && (
          <div className="h-full flex flex-col justify-between space-y-6 animate-fadeIn">
            <div className="flex items-center justify-between">
              <span className="text-amber-400 text-xs font-mono font-bold tracking-[0.25em] uppercase">
                I N T R O D U C T I O N
              </span>
              <div className="w-12 h-12 rounded-full bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
                <Users className="w-6 h-6" />
              </div>
            </div>

            <div className="space-y-4 max-w-4xl">
              <h1 className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-tight">
                Efficient Text Search and Retrieval Techniques for Healthcare Systems
              </h1>
              <h2 className="text-base sm:text-xl text-amber-300 font-serif italic">
                Dictionary Query Engine with Minimum Edit Distance
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
                In modern healthcare systems, quick and accurate retrieval of medical information — drug names, symptoms, and diagnoses — is critical. This project introduces a dictionary-based query engine that applies the Minimum Edit Distance algorithm to enable smart, typo-tolerant search, helping clinicians and patients find the right health term even when it is entered incorrectly.
              </p>
            </div>

            <div>
              <span className="text-[11px] font-mono tracking-widest uppercase text-slate-400 font-bold block mb-3">
                T E A M &nbsp; M E M B E R S
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {TEAM_MEMBERS.map((member) => (
                  <div
                    key={member.rollNo}
                    className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-2.5"
                  >
                    <div className="w-9 h-9 rounded-full bg-amber-400/20 text-amber-300 font-bold text-xs flex items-center justify-center font-mono shrink-0">
                      {member.initials}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white truncate">
                        {member.name}
                      </div>
                      <div className="text-[10px] font-mono text-slate-400">
                        {member.rollNo}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-3 border-t border-slate-800/60">
              <span>B.Tech Final Year Project | Department of Computer Science</span>
              <span>01</span>
            </div>
          </div>
        )}

        {/* Slide 2: Abstract */}
        {currentSlide === 2 && (
          <div className="h-full flex flex-col justify-between space-y-6 animate-fadeIn">
            <span className="text-amber-400 text-xs font-mono font-bold tracking-[0.25em] uppercase">
              A B S T R A C T
            </span>

            <div className="space-y-4">
              <h2 className="text-2xl sm:text-4xl font-bold text-white tracking-tight">
                Project Abstract
              </h2>

              <div className="p-4 sm:p-6 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                <span className="text-amber-400 text-xs font-mono font-bold tracking-wider uppercase">
                  KEY IDEA
                </span>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Healthcare data — medical dictionaries, drug names, symptom descriptions, and diagnosis codes — is frequently entered manually and is prone to spelling errors. Conventional exact-match search systems fail whenever a query does not perfectly match a dictionary entry, leading to lost time and missed information.
                </p>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                This project proposes a Dictionary Query Engine that combines a curated health-data dictionary with the Minimum Edit Distance (Levenshtein Distance) algorithm. Using dynamic programming, the engine computes the closeness between a user&apos;s query and every dictionary entry, then returns the most relevant matches ranked by similarity — even when the query contains typographical errors. The result is a faster, more forgiving, and more accurate retrieval experience for smart health data systems.
              </p>

              {/* 3-step pipeline graphic */}
              <div className="grid grid-cols-3 gap-4 pt-4 text-center">
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-amber-400 text-xs font-mono font-bold block mb-1">
                    INPUT
                  </span>
                  <p className="text-xs text-slate-300">
                    A possibly misspelled health term
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-900 border border-amber-500/40 ring-1 ring-amber-500/20">
                  <span className="text-amber-400 text-xs font-mono font-bold block mb-1">
                    ENGINE
                  </span>
                  <p className="text-xs text-slate-300">
                    Dictionary + Minimum Edit Distance (DP)
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-amber-400 text-xs font-mono font-bold block mb-1">
                    OUTPUT
                  </span>
                  <p className="text-xs text-slate-300">
                    Ranked list of closest correct matches
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-3 border-t border-slate-800/60">
              <span>HealthQuery Abstract Architecture</span>
              <span>02</span>
            </div>
          </div>
        )}

        {/* Slide 3: Problem Statement */}
        {currentSlide === 3 && (
          <div className="h-full flex flex-col justify-between space-y-6 animate-fadeIn">
            <span className="text-amber-400 text-xs font-mono font-bold tracking-[0.25em] uppercase">
              P R O B L E M &nbsp; S T A T E M E N T
            </span>

            <div className="space-y-4">
              <h2 className="text-2xl sm:text-4xl font-bold text-white tracking-tight">
                The Challenge We&apos;re Solving
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2 relative">
                  <span className="absolute top-4 right-4 text-slate-600 font-mono text-lg font-bold">
                    01
                  </span>
                  <h3 className="text-base font-bold text-white">Manual Entry Errors</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Clinicians, pharmacists, and patients frequently mistype medical terms, drug names, and symptoms.
                  </p>
                </div>

                <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2 relative">
                  <span className="absolute top-4 right-4 text-slate-600 font-mono text-lg font-bold">
                    02
                  </span>
                  <h3 className="text-base font-bold text-white">Exact-Match Failure</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Traditional dictionary lookups return zero results the moment a query doesn&apos;t match perfectly.
                  </p>
                </div>

                <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2 relative">
                  <span className="absolute top-4 right-4 text-slate-600 font-mono text-lg font-bold">
                    03
                  </span>
                  <h3 className="text-base font-bold text-white">Delayed Retrieval</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Failed searches force manual re-entry or browsing, slowing down time-sensitive health decisions.
                  </p>
                </div>

                <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2 relative">
                  <span className="absolute top-4 right-4 text-slate-600 font-mono text-lg font-bold">
                    04
                  </span>
                  <h3 className="text-base font-bold text-white">No Fuzzy Matching</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Most existing health-data systems lack a robust, typo-tolerant search mechanism.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-3 border-t border-slate-800/60">
              <span>Healthcare Information Retrieval Challenges</span>
              <span>03</span>
            </div>
          </div>
        )}

        {/* Slide 4: Proposed System / Functionalities */}
        {currentSlide === 4 && (
          <div className="h-full flex flex-col justify-between space-y-4 animate-fadeIn">
            <span className="text-amber-400 text-xs font-mono font-bold tracking-[0.25em] uppercase">
              P R O P O S E D &nbsp; S Y S T E M
            </span>

            <div className="space-y-3">
              <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                Proposed Functionalities
              </h2>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-slate-500 font-mono text-xs font-bold">01</span>
                  <h4 className="text-sm font-bold text-white">Structured Health Dictionary</h4>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Store diseases, symptoms, and drug names in an efficient, searchable structure.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-slate-500 font-mono text-xs font-bold">02</span>
                  <h4 className="text-sm font-bold text-white">Real-Time Query Processing</h4>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Deliver suggestions instantly as the user types or submits a query.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-slate-500 font-mono text-xs font-bold">03</span>
                  <h4 className="text-sm font-bold text-white">Edit-Distance Fuzzy Search</h4>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Compute Levenshtein distance via dynamic programming to score candidate terms.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-slate-500 font-mono text-xs font-bold">04</span>
                  <h4 className="text-sm font-bold text-white">Scalable Dictionary Support</h4>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Designed to extend to larger, multi-specialty medical vocabularies.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-slate-500 font-mono text-xs font-bold">05</span>
                  <h4 className="text-sm font-bold text-white">Ranked Suggestions</h4>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Return the closest matches ordered by similarity, not just a single best guess.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-slate-500 font-mono text-xs font-bold">06</span>
                  <h4 className="text-sm font-bold text-white">Simple Query Interface</h4>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    An easy-to-use search interface for both clinicians and patients.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-2 border-t border-slate-800/60">
              <span>Proposed Functional Capabilities</span>
              <span>04</span>
            </div>
          </div>
        )}

        {/* Slide 5: Tools & Technologies Used */}
        {currentSlide === 5 && (
          <div className="h-full flex flex-col justify-between space-y-6 animate-fadeIn">
            <span className="text-amber-400 text-xs font-mono font-bold tracking-[0.25em] uppercase">
              I M P L E M E N T A T I O N
            </span>

            <div className="space-y-4">
              <h2 className="text-2xl sm:text-4xl font-bold text-white tracking-tight">
                Tools &amp; Technologies Used
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Core Stack */}
                <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
                  <span className="text-amber-400 text-xs font-mono font-bold uppercase tracking-wider">
                    CORE STACK
                  </span>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-lg bg-amber-400 text-slate-950 font-bold flex items-center justify-center shrink-0">
                        Jv
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">Java</h4>
                        <p className="text-xs text-slate-400">
                          Core language for algorithm implementation and testing
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-lg bg-amber-400 text-slate-950 font-bold flex items-center justify-center shrink-0">
                        DP
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">Dynamic Programming</h4>
                        <p className="text-xs text-slate-400">
                          Bottom-up edit distance matrix computation
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Supporting Tools */}
                <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
                  <span className="text-slate-400 text-xs font-mono font-bold uppercase tracking-wider">
                    SUPPORTING TOOLS
                  </span>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                      <span className="text-xs font-bold text-amber-400 font-mono block">Tr</span>
                      <strong className="text-xs text-white block">Trie / HashMap</strong>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Efficient dictionary storage using Java collections
                      </p>
                    </div>

                    <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                      <span className="text-xs font-bold text-amber-400 font-mono block">DB</span>
                      <strong className="text-xs text-white block">Medical Corpus</strong>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Curated dataset of diseases, symptoms &amp; drugs
                      </p>
                    </div>

                    <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                      <span className="text-xs font-bold text-amber-400 font-mono block">UI</span>
                      <strong className="text-xs text-white block">Query Interface</strong>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Simple search interface for real-time suggestions
                      </p>
                    </div>

                    <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                      <span className="text-xs font-bold text-amber-400 font-mono block">Ts</span>
                      <strong className="text-xs text-white block">JUnit Testing</strong>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Validating accuracy across misspelling scenarios
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-3 border-t border-slate-800/60">
              <span>Technology Stack & Architecture</span>
              <span>05</span>
            </div>
          </div>
        )}

        {/* Slide 6: Expected Outcome */}
        {currentSlide === 6 && (
          <div className="h-full flex flex-col justify-between space-y-4 animate-fadeIn">
            <span className="text-amber-400 text-xs font-mono font-bold tracking-[0.25em] uppercase">
              E X P E C T E D &nbsp; O U T C O M E
            </span>

            <div className="space-y-3">
              <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                What We Expect to Achieve
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                <div className="md:col-span-6 space-y-3 text-xs sm:text-sm">
                  <div className="flex items-start gap-2.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                    <p className="text-slate-200">
                      A working query engine that tolerates spelling errors instead of returning zero results
                    </p>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                    <p className="text-slate-200">
                      Noticeably higher search success rate compared to exact-match lookups
                    </p>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                    <p className="text-slate-200">
                      Fast, ranked suggestions suitable for real-time clinical and patient use
                    </p>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                    <p className="text-slate-200">
                      A reusable foundation that can extend to larger dictionaries and future NLP features
                    </p>
                  </div>
                </div>

                <div className="md:col-span-6 p-4 rounded-xl bg-slate-900 border border-slate-800 text-center">
                  <span className="text-[11px] font-mono tracking-wider uppercase text-slate-400 font-bold block mb-4">
                    EXPECTED QUERY SUCCESS RATE
                  </span>

                  <div className="flex items-end justify-center gap-8 h-40 pb-2">
                    {/* Exact match bar */}
                    <div className="flex flex-col items-center gap-2">
                      <span className="text-xs font-mono font-bold text-slate-300">58%</span>
                      <div className="w-16 sm:w-20 bg-blue-900 rounded-t-md h-24" />
                      <span className="text-[11px] text-slate-400 max-w-[80px]">
                        Exact-Match Search
                      </span>
                    </div>

                    {/* Proposed Fuzzy bar */}
                    <div className="flex flex-col items-center gap-2">
                      <span className="text-xs font-mono font-bold text-amber-300">96%</span>
                      <div className="w-16 sm:w-20 bg-amber-500 rounded-t-md h-36" />
                      <span className="text-[11px] text-amber-300 font-semibold max-w-[80px]">
                        Proposed Fuzzy Engine
                      </span>
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-500 italic mt-2">
                    (Illustrative projection based on typical fuzzy-matching improvements)
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-2 border-t border-slate-800/60">
              <span>Expected Success Rate Metrics</span>
              <span>06</span>
            </div>
          </div>
        )}

        {/* Slide 7: Thank You */}
        {currentSlide === 7 && (
          <div className="h-full flex flex-col justify-between items-center text-center py-6 space-y-6 animate-fadeIn">
            <div className="w-16 h-16 rounded-full bg-amber-400 flex items-center justify-center text-slate-950 shadow-xl shadow-amber-400/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-4">
              <h2 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
                Thank You
              </h2>
              <p className="text-sm sm:text-base text-amber-300 font-serif italic">
                Efficient Text Search and Retrieval Techniques for Healthcare Systems
              </p>
              <p className="text-xs sm:text-sm text-slate-400">
                Questions &amp; Discussion Welcome
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-400 font-mono max-w-md">
              <span>Presented by: M. Mohana Asmitha, G. Laasya, Ch. Nohitha, K. Dheeraj</span>
              <div className="text-slate-500 text-[11px] mt-1">
                Department of Computer Science • B.Tech Final Year
              </div>
            </div>

            <div className="w-full flex items-center justify-between text-[11px] text-slate-500 font-mono pt-3 border-t border-slate-800/60">
              <span>Q&amp;A Session</span>
              <span>07</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
