import { X, Pill, Stethoscope, Activity, Calendar, Phone, User, Building, HeartPulse, FileText, ArrowRight } from 'lucide-react';
import { Patient } from '../types/index.ts';

interface PatientDetailsModalProps {
  patient: Patient | null;
  onClose: () => void;
  onInspectDP?: (query: string, target: string) => void;
  currentQuery?: string;
}

export function PatientDetailsModal({
  patient,
  onClose,
  onInspectDP,
  currentQuery
}: PatientDetailsModalProps) {
  if (!patient) return null;

  const getStatusBadge = (status: Patient['status']) => {
    switch (status) {
      case 'Critical':
        return 'bg-rose-500/20 text-rose-400 border-rose-500/30';
      case 'Inpatient':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'Outpatient':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'Discharged':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 bg-slate-900/90 flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 font-bold font-mono text-xl flex items-center justify-center shadow-lg shadow-amber-500/20">
              {patient.name.split(' ').map((n) => n[0]).join('')}
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h3 className="text-xl font-bold text-white tracking-tight">{patient.name}</h3>
                <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold border ${getStatusBadge(patient.status)}`}>
                  {patient.status}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-1 font-mono">
                <span className="text-amber-400 font-bold">{patient.id}</span>
                <span>•</span>
                <span>{patient.age} yrs, {patient.gender}</span>
                <span>•</span>
                <span className="text-rose-400 font-semibold">{patient.bloodGroup}</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto text-xs">
          {/* Quick Demographics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-500 font-mono text-[10px] uppercase block">Admission</span>
              <div className="flex items-center gap-1.5 text-slate-200 font-mono mt-0.5 font-medium">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                <span>{patient.admissionDate}</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-500 font-mono text-[10px] uppercase block">Emergency Contact</span>
              <div className="flex items-center gap-1.5 text-slate-200 font-mono mt-0.5 font-medium truncate">
                <Phone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="truncate">{patient.contact}</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-500 font-mono text-[10px] uppercase block">Department</span>
              <div className="flex items-center gap-1.5 text-slate-200 font-mono mt-0.5 font-medium truncate">
                <Building className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="truncate">{patient.department}</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-500 font-mono text-[10px] uppercase block">Physician</span>
              <div className="flex items-center gap-1.5 text-slate-200 font-mono mt-0.5 font-medium truncate">
                <User className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="truncate">{patient.attendingPhysician.split(',')[0]}</span>
              </div>
            </div>
          </div>

          {/* Primary Diagnosis Card */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-amber-400 text-[10px] font-mono font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Stethoscope className="w-3.5 h-3.5" />
                <span>Clinical Diagnosis</span>
              </span>

              {currentQuery && onInspectDP && (
                <button
                  type="button"
                  onClick={() => onInspectDP(currentQuery, patient.diagnosis)}
                  className="text-amber-400 hover:text-amber-300 font-mono text-[11px] flex items-center gap-1 cursor-pointer"
                >
                  <span>Inspect DP Matrix for &quot;{patient.diagnosis}&quot;</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              )}
            </div>

            <h4 className="text-base font-bold text-white">{patient.diagnosis}</h4>
            <div className="text-slate-400 text-[11px] leading-relaxed">
              Attending: <strong className="text-slate-200">{patient.attendingPhysician}</strong> • Ward: <span className="text-slate-300">{patient.department}</span>
            </div>
          </div>

          {/* Symptoms List */}
          <div className="space-y-2">
            <span className="text-slate-400 font-mono text-[10px] uppercase tracking-wider block font-bold flex items-center gap-1.5">
              <HeartPulse className="w-3.5 h-3.5 text-rose-400" />
              <span>Reported Symptoms &amp; Signs</span>
            </span>
            <div className="flex flex-wrap gap-2">
              {patient.symptoms.map((s) => (
                <span
                  key={s}
                  className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-mono text-xs"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>

          {/* Prescribed Medications Table */}
          <div className="space-y-2">
            <span className="text-slate-400 font-mono text-[10px] uppercase tracking-wider block font-bold flex items-center gap-1.5">
              <Pill className="w-3.5 h-3.5 text-amber-400" />
              <span>Prescribed Medications &amp; Posology</span>
            </span>

            <div className="rounded-xl border border-slate-800 overflow-hidden">
              <table className="w-full text-left font-mono text-xs">
                <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase border-b border-slate-800">
                  <tr>
                    <th className="p-2.5">Medication</th>
                    <th className="p-2.5">Dosage</th>
                    <th className="p-2.5">Posology / Frequency</th>
                    {onInspectDP && currentQuery && <th className="p-2.5 text-right">DP Match</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 bg-slate-900">
                  {patient.medications.map((m, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/40">
                      <td className="p-2.5 font-bold text-white flex items-center gap-1.5">
                        <Pill className="w-3 h-3 text-amber-400 shrink-0" />
                        <span>{m.drugName}</span>
                      </td>
                      <td className="p-2.5 text-amber-300">{m.dosage}</td>
                      <td className="p-2.5 text-slate-300">{m.frequency}</td>
                      {onInspectDP && currentQuery && (
                        <td className="p-2.5 text-right">
                          <button
                            type="button"
                            onClick={() => onInspectDP(currentQuery, m.drugName)}
                            className="text-[10px] text-amber-400 hover:text-amber-300 underline cursor-pointer"
                          >
                            Trace DP
                          </button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Clinical Case Notes */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-slate-400 font-mono text-[10px] uppercase tracking-wider block font-bold flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-amber-400" />
              <span>Clinical Progress Notes</span>
            </span>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {patient.notes}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between">
          <span className="text-[11px] font-mono text-slate-500">
            HealthQuery DSA Record • Indexed in Local In-Memory &amp; LocalStorage DB
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono transition cursor-pointer"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
}
