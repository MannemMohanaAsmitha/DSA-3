import { useState, useMemo, useEffect, useRef } from 'react';
import {
  Users,
  Search,
  Plus,
  RotateCcw,
  Sparkles,
  Pill,
  Stethoscope,
  Activity,
  ArrowRight,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Cpu,
  ChevronLeft,
  ChevronRight,
  Building,
  HeartPulse,
  LayoutGrid,
  Table as TableIcon,
  Phone,
  User,
  Calendar,
  FileText,
  Zap,
  X
} from 'lucide-react';
import { Patient, PatientSearchResult } from '../types/index.ts';
import { searchPatients } from '../utils/patientSearch.ts';
import { AddPatientModal } from './AddPatientModal.tsx';
import { PatientDetailsModal } from './PatientDetailsModal.tsx';

interface PatientDirectoryViewProps {
  patients: Patient[];
  onAddPatient: (patient: Patient) => void;
  onResetPatients: () => void;
  onInspectDP: (s1: string, s2: string) => void;
}

export function PatientDirectoryView({
  patients,
  onAddPatient,
  onResetPatients,
  onInspectDP
}: PatientDirectoryViewProps) {
  // Default to empty string so ALL 1,000 patients are immediately generated and viewable!
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [deptFilter, setDeptFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [maxDistance, setMaxDistance] = useState<number>(2);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(12);
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');

  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);

  // Automated spelling correction state
  const [autoCorrectActive, setAutoCorrectActive] = useState<boolean>(true);
  const [autoCorrectionNotice, setAutoCorrectionNotice] = useState<{
    original: string;
    corrected: string;
    distance: number;
    similarity: number;
    categoryLabel?: string;
  } | null>(null);

  // Dynamic department list from actual patient records
  const availableDepartments = useMemo(() => {
    const depts = new Set<string>();
    patients.forEach((p) => {
      if (p.department) depts.add(p.department);
    });
    return Array.from(depts).sort();
  }, [patients]);

  // Compute next ID for new patient (e.g. PID-2001)
  const nextPatientId = useMemo(() => {
    const maxNum = patients.reduce((max, p) => {
      const num = parseInt(p.id.replace('PID-', ''), 10);
      return !isNaN(num) && num > max ? num : max;
    }, 1000);
    return `PID-${maxNum + 1}`;
  }, [patients]);

  // Execute DSA search with live dictionary mistake detection
  const { results, latencyMs, scannedCount, detectedMistake } = useMemo(() => {
    return searchPatients(searchQuery, patients, {
      maxDistance,
      departmentFilter: deptFilter,
      statusFilter: statusFilter
    });
  }, [searchQuery, patients, maxDistance, deptFilter, statusFilter]);

  // Trigger automated correction
  const applyAutoCorrection = (mistake: NonNullable<typeof detectedMistake>) => {
    if (!mistake || mistake.editDistance === 0) return;
    setAutoCorrectionNotice({
      original: mistake.originalQuery,
      corrected: mistake.correctedTerm,
      distance: mistake.editDistance,
      similarity: mistake.similarity,
      categoryLabel: mistake.categoryLabel
    });
    setSearchQuery(mistake.correctedTerm);
    setCurrentPage(1);
  };

  const handleUndoCorrection = () => {
    if (!autoCorrectionNotice) return;
    const orig = autoCorrectionNotice.original;
    setAutoCorrectionNotice(null);
    setSearchQuery(orig);
  };

  // Automated correction on typing debounce
  const autoCorrectTimerRef = useRef<NodeJS.Timeout | null>(null);
  useEffect(() => {
    if (!autoCorrectActive || !detectedMistake || detectedMistake.editDistance === 0) return;
    if (detectedMistake.originalQuery.toLowerCase() === detectedMistake.correctedTerm.toLowerCase()) return;

    if (autoCorrectTimerRef.current) clearTimeout(autoCorrectTimerRef.current);
    autoCorrectTimerRef.current = setTimeout(() => {
      applyAutoCorrection(detectedMistake);
    }, 900);

    return () => {
      if (autoCorrectTimerRef.current) clearTimeout(autoCorrectTimerRef.current);
    };
  }, [searchQuery, detectedMistake, autoCorrectActive]);

  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      if (detectedMistake && detectedMistake.editDistance > 0) {
        e.preventDefault();
        applyAutoCorrection(detectedMistake);
      }
    }
  };

  const handleSearchBlur = () => {
    if (autoCorrectActive && detectedMistake && detectedMistake.editDistance > 0) {
      applyAutoCorrection(detectedMistake);
    }
  };

  // Pagination calculation
  const totalPages = Math.max(1, Math.ceil(results.length / pageSize));
  const paginatedResults = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return results.slice(start, start + pageSize);
  }, [results, currentPage, pageSize]);


  const handleQueryPreset = (term: string) => {
    setSearchQuery(term);
    setCurrentPage(1);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    const container = document.getElementById('patient-directory-container');
    if (container) {
      container.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Status badge styling
  const getStatusBadge = (status: Patient['status']) => {
    switch (status) {
      case 'Critical':
        return 'bg-rose-500/20 text-rose-400 border-rose-500/30';
      case 'Inpatient':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'Outpatient':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'Discharged':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    }
  };

  // Quick stats
  const inpatientCount = patients.filter((p) => p.status === 'Inpatient').length;
  const criticalCount = patients.filter((p) => p.status === 'Critical').length;
  const outpatientCount = patients.filter((p) => p.status === 'Outpatient').length;
  const dischargedCount = patients.filter((p) => p.status === 'Discharged').length;

  return (
    <div className="space-y-6" id="patient-directory-container">
      {/* Top Banner with Stats & Actions */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 font-bold flex items-center justify-center shadow-lg shadow-amber-500/20 shrink-0">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                    1,000 Patient Records Clinical Dataset
                  </h2>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-400/20 text-emerald-300 text-xs font-mono font-bold border border-emerald-400/30">
                    Live Indexed • {patients.length} Records
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Complete personal details, diseases &amp; diagnosis, symptoms, and medications with DSA Dictionary Error Mistake Detection
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold font-mono text-xs shadow-lg shadow-amber-500/20 transition active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Patient Record</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (confirm('Reset to standard 1,000 seed patient records?')) {
                  onResetPatients();
                  setSearchQuery('');
                }
              }}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs transition cursor-pointer"
              title="Reset to 1,000 default patients"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset 1,000 DB</span>
            </button>
          </div>
        </div>

        {/* Quick Metric Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-5 text-xs font-mono">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 text-[10px] uppercase block">Total Database Size</span>
            <div className="text-lg font-bold text-white mt-0.5">{patients.length} Patients</div>
            <div className="text-[10px] text-emerald-400">All information loaded</div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 text-[10px] uppercase block">Inpatient Admissions</span>
            <div className="text-lg font-bold text-amber-300 mt-0.5">{inpatientCount} Admitted</div>
            <div className="text-[10px] text-slate-500">Currently in hospital ward</div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 text-[10px] uppercase block">Critical Care / ICU</span>
            <div className="text-lg font-bold text-rose-400 mt-0.5">{criticalCount} Critical</div>
            <div className="text-[10px] text-slate-500">Monitored round the clock</div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-500 text-[10px] uppercase block">Outpatient Consults</span>
            <div className="text-lg font-bold text-blue-400 mt-0.5">{outpatientCount} Consults</div>
            <div className="text-[10px] text-slate-500">Routine follow-ups</div>
          </div>
        </div>
      </div>

      {/* Typo-Tolerant Search & Filter Console */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4 shadow-lg">
        <div className="space-y-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <label htmlFor="patient-search-input" className="text-xs font-mono font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Search className="w-3.5 h-3.5" />
              <span>DSA Typo-Tolerant Query &amp; Dictionary Engine</span>
            </label>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setAutoCorrectActive(!autoCorrectActive)}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono font-semibold flex items-center gap-1.5 transition cursor-pointer border ${
                  autoCorrectActive
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
                title="Toggle automated spelling correction on search input"
              >
                <Zap className={`w-3.5 h-3.5 ${autoCorrectActive ? 'text-emerald-400' : ''}`} />
                <span>Auto-Correct: {autoCorrectActive ? 'ON' : 'OFF'}</span>
              </button>
              <div className="flex items-center gap-2 text-slate-400 font-mono text-[11px]">
                <Cpu className="w-3.5 h-3.5 text-amber-400" />
                <span>Scanned: {scannedCount} / {patients.length}</span>
                <span>•</span>
                <span className="text-emerald-400 font-semibold">{latencyMs} ms latency</span>
              </div>
            </div>
          </div>

          <div className="relative">
            <Search className="w-5 h-5 text-slate-500 absolute left-4 top-3.5" />
            <input
              id="patient-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              onKeyDown={handleSearchKeyDown}
              onBlur={handleSearchBlur}
              placeholder="Search by Patient Name (e.g. Aravnd), Diagnosis (dibetes), Medication (paracetmol), or Symptom (dispnea)..."
              className="w-full pl-12 pr-32 py-3 bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl text-white text-sm font-mono focus:outline-none transition shadow-inner"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setAutoCorrectionNotice(null);
                  setCurrentPage(1);
                }}
                className="absolute right-3 top-2.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-mono transition cursor-pointer"
              >
                Clear (Show 1000)
              </button>
            )}
          </div>
        </div>

        {/* Auto-Correction Notice Banner */}
        {autoCorrectionNotice && (
          <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 flex items-center justify-between gap-3 text-xs animate-in fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <span>
                  Auto-corrected:{' '}
                  <span className="line-through text-rose-300 font-mono font-semibold">&quot;{autoCorrectionNotice.original}&quot;</span>
                  {' '}➔{' '}
                  <strong className="text-white font-mono">&quot;{autoCorrectionNotice.corrected}&quot;</strong>
                </span>
                <span className="ml-2 text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Levenshtein Distance: {autoCorrectionNotice.distance} • {autoCorrectionNotice.similarity}% Match
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleUndoCorrection}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-mono text-[11px] transition cursor-pointer"
              >
                Undo
              </button>
              <button
                type="button"
                onClick={() => setAutoCorrectionNotice(null)}
                className="p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* DICTIONARY QUERY ENGINE: ERROR MISTAKE DETECTION & AUTO-CORRECTION PANEL */}
        {detectedMistake && (
          <div className="p-4 rounded-xl bg-gradient-to-r from-amber-500/15 via-slate-900 to-amber-500/10 border border-amber-500/40 text-amber-200 space-y-3 animate-in fade-in slide-in-from-top-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-amber-500/20">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                <div>
                  <span className="font-bold text-sm text-white">
                    Spelling Error Detected: &quot;{detectedMistake.originalQuery}&quot;
                  </span>
                  <span className="ml-2 text-xs font-mono px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                    {detectedMistake.errorType} Error (Edit Distance: {detectedMistake.editDistance})
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-emerald-400 font-semibold">
                  {detectedMistake.similarity}% Match
                </span>
              </div>
            </div>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
              <div className="space-y-1">
                <div className="text-slate-300">
                  {detectedMistake.explanation}
                </div>
                <div className="text-slate-200">
                  Dictionary Query Engine Auto-Correction:{' '}
                  <strong className="text-amber-300 text-sm font-semibold underline decoration-amber-400 underline-offset-4">
                    {detectedMistake.correctedTerm}
                  </strong>{' '}
                  <span className="text-slate-400 font-mono text-[11px]">({detectedMistake.categoryLabel})</span>
                  {autoCorrectActive && (
                    <span className="ml-2 text-[10px] text-emerald-400 font-mono">
                      (Auto-correcting automatically...)
                    </span>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => applyAutoCorrection(detectedMistake)}
                  className="px-3.5 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Auto-Correct Now: &quot;{detectedMistake.correctedTerm}&quot;</span>
                </button>

                <button
                  type="button"
                  onClick={() => onInspectDP(detectedMistake.originalQuery, detectedMistake.correctedTerm)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-mono text-xs border border-amber-500/30 flex items-center gap-1 transition cursor-pointer"
                >
                  <span>Inspect 2D DP Matrix</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Preset Typo Chips for Fast Evaluation */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          <span className="text-[11px] font-mono text-slate-400 mr-1 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>Try Typo Mistakes:</span>
          </span>

          {[
            { typo: 'dibetes', label: '"dibetes" ➔ Diabetes' },
            { typo: 'paracetmol', label: '"paracetmol" ➔ Paracetamol' },
            { typo: 'hypertnnsion', label: '"hypertnnsion" ➔ Hypertension' },
            { typo: 'asthema', label: '"asthema" ➔ Asthma' },
            { typo: 'dispnea', label: '"dispnea" ➔ Dyspnea' },
            { typo: 'amoxiclin', label: '"amoxiclin" ➔ Amoxicillin' },
            { typo: 'Aravnd', label: '"Aravnd" ➔ Aravind (Name)' }
          ].map((item) => (
            <button
              key={item.typo}
              type="button"
              onClick={() => handleQueryPreset(item.typo)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono transition cursor-pointer ${
                searchQuery === item.typo
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800'
              }`}
            >
              {item.label}
            </button>
          ))}

          {searchQuery && (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setCurrentPage(1);
              }}
              className="px-2.5 py-1 rounded-lg text-xs font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30 transition cursor-pointer ml-auto"
            >
              Show All 1,000 Records
            </button>
          )}
        </div>

        {/* Filter Controls Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-3 border-t border-slate-800 text-xs">
          {/* Department Filter */}
          <div className="sm:col-span-4">
            <label className="block text-[11px] font-mono text-slate-400 mb-1">
              Filter by Department
            </label>
            <select
              value={deptFilter}
              onChange={(e) => {
                setDeptFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:border-amber-400 focus:outline-none cursor-pointer"
            >
              <option value="all">All Departments ({patients.length} Patients)</option>
              {availableDepartments.map((dept) => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="sm:col-span-4">
            <label className="block text-[11px] font-mono text-slate-400 mb-1">
              Filter by Care Status
            </label>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:border-amber-400 focus:outline-none cursor-pointer"
            >
              <option value="all">All Care Statuses</option>
              <option value="Inpatient">Inpatient</option>
              <option value="Critical">Critical (ICU)</option>
              <option value="Outpatient">Outpatient</option>
              <option value="Discharged">Discharged</option>
            </select>
          </div>

          {/* Edit Distance Tolerance */}
          <div className="sm:col-span-4">
            <div className="flex items-center justify-between mb-1">
              <label className="text-[11px] font-mono text-slate-400">
                Levenshtein Distance Limit:
              </label>
              <span className="font-mono font-bold text-amber-400">
                &le; {maxDistance} edit operations
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={3}
              step={1}
              value={maxDistance}
              onChange={(e) => {
                setMaxDistance(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Results Header with View Mode Toggles */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-1">
        <div className="text-xs font-mono text-slate-400">
          Showing{' '}
          <strong className="text-white">
            {results.length === 0 ? 0 : (currentPage - 1) * pageSize + 1} -{' '}
            {Math.min(currentPage * pageSize, results.length)}
          </strong>{' '}
          of <strong className="text-amber-400">{results.length}</strong> matching clinical records
          {searchQuery && (
            <span> for &quot;<span className="text-white">{searchQuery}</span>&quot;</span>
          )}
        </div>

        <div className="flex items-center gap-3">
          {/* Per Page Selector */}
          <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
            <span>Show:</span>
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="px-2 py-1 bg-slate-900 border border-slate-800 rounded text-slate-200 text-xs focus:outline-none cursor-pointer"
            >
              <option value={12}>12 records</option>
              <option value={24}>24 records</option>
              <option value={50}>50 records</option>
              <option value={100}>100 records</option>
            </select>
          </div>

          {/* View Mode Toggle: Cards vs Table */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1">
            <button
              type="button"
              onClick={() => setViewMode('cards')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono transition cursor-pointer ${
                viewMode === 'cards'
                  ? 'bg-amber-400 text-slate-950 font-bold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Full Dossier Cards</span>
            </button>

            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono transition cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-amber-400 text-slate-950 font-bold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span>Dense Table</span>
            </button>
          </div>
        </div>
      </div>

      {/* VIEW MODE 1: COMPREHENSIVE CLINICAL DOSSIER CARDS (Generates All Personal Details, Diseases, Diagnosis, and Medications) */}
      {viewMode === 'cards' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {paginatedResults.length === 0 ? (
            <div className="col-span-full py-16 text-center text-slate-500 font-mono bg-slate-900 rounded-2xl border border-slate-800 p-8">
              <p className="text-base text-slate-400">No patients found matching &quot;{searchQuery}&quot;</p>
              <p className="text-xs mt-1 text-slate-600">
                Try increasing the edit-distance slider or clicking &quot;Show All 1,000 Records&quot;
              </p>
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="mt-4 px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs font-mono cursor-pointer"
              >
                Clear Search &amp; Show 1,000 Patients
              </button>
            </div>
          ) : (
            paginatedResults.map(({ patient, matchedField, matchedValue, distance, similarity, exactMatch, correctedTerm, errorType }) => (
              <div
                key={patient.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 shadow-lg flex flex-col justify-between space-y-4 hover:shadow-xl transition group"
              >
                {/* Header: ID, Name, Status */}
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400/20 to-amber-600/30 text-amber-300 border border-amber-400/30 font-bold font-mono text-sm flex items-center justify-center shrink-0">
                        {patient.name.split(' ').map((n) => n[0]).join('')}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-white group-hover:text-amber-300 transition text-sm">
                            {patient.name}
                          </h4>
                        </div>
                        <div className="text-[11px] text-amber-400 font-mono">
                          {patient.id}
                        </div>
                      </div>
                    </div>

                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold border ${getStatusBadge(patient.status)}`}>
                      {patient.status}
                    </span>
                  </div>

                  {/* Typo Correction Tag if active */}
                  {correctedTerm && (
                    <div className="mt-2 px-2 py-1 rounded bg-amber-500/10 border border-amber-500/30 text-amber-200 text-[10px] font-mono flex items-center justify-between">
                      <span>Error Corrected: &quot;{searchQuery}&quot; ➔ <strong>{correctedTerm}</strong></span>
                      <span className="text-slate-400">Dist: {distance}</span>
                    </div>
                  )}

                  {/* Personal Details */}
                  <div className="mt-3 pt-3 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-xs font-mono text-slate-300">
                    <div>
                      <span className="text-slate-500 text-[10px] block">Demographics</span>
                      <span className="text-white font-medium">{patient.age} yrs, {patient.gender}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 text-[10px] block">Blood Group</span>
                      <span className="text-rose-400 font-bold">{patient.bloodGroup}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 text-[10px] block">Contact</span>
                      <span className="text-slate-300 truncate block">{patient.contact}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 text-[10px] block">Admission</span>
                      <span className="text-slate-300">{patient.admissionDate}</span>
                    </div>
                  </div>

                  {/* Diseases & Diagnosis */}
                  <div className="mt-3 pt-3 border-t border-slate-800/80">
                    <span className="text-slate-500 text-[10px] font-mono uppercase block mb-1">
                      Primary Disease / Diagnosis
                    </span>
                    <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                      <div className="font-semibold text-slate-100 text-xs flex items-center justify-between">
                        <span>{patient.diagnosis}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-amber-300 font-mono">
                          {patient.department}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono mt-1">
                        Doctor: {patient.attendingPhysician.split(',')[0]}
                      </div>
                    </div>
                  </div>

                  {/* Symptoms */}
                  <div className="mt-3">
                    <span className="text-slate-500 text-[10px] font-mono uppercase block mb-1">
                      Reported Symptoms
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {patient.symptoms.map((sym, sIdx) => (
                        <span
                          key={sIdx}
                          className="px-2 py-0.5 rounded-md bg-slate-950 border border-slate-800 text-[10px] text-slate-300 font-mono"
                        >
                          {sym}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Prescribed Medications */}
                  <div className="mt-3">
                    <span className="text-slate-500 text-[10px] font-mono uppercase block mb-1">
                      Prescribed Medications ({patient.medications.length})
                    </span>
                    <div className="space-y-1">
                      {patient.medications.map((med, mIdx) => (
                        <div
                          key={mIdx}
                          className="p-1.5 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-between text-[11px] font-mono"
                        >
                          <div className="flex items-center gap-1.5 text-amber-300 font-semibold truncate">
                            <Pill className="w-3 h-3 text-amber-400 shrink-0" />
                            <span className="truncate">{med.drugName}</span>
                          </div>
                          <div className="text-slate-400 text-[10px] shrink-0">
                            {med.dosage} • {med.frequency}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Footer Actions */}
                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2 font-mono text-xs">
                  <button
                    type="button"
                    onClick={() => setSelectedPatient(patient)}
                    className="flex-1 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-center font-medium transition cursor-pointer"
                  >
                    View Dossier
                  </button>

                  <button
                    type="button"
                    onClick={() => onInspectDP(searchQuery || 'dibetes', patient.diagnosis)}
                    className="px-2.5 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] transition cursor-pointer flex items-center gap-1"
                    title="Trace Dynamic Programming Alignment"
                  >
                    <span>DP Matrix</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      ) : (
        /* VIEW MODE 2: DENSE CLINICAL TABLE */
        <div
          id="patient-records-table"
          className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-xl"
        >
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead className="bg-slate-950 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3.5 px-4">Patient ID &amp; Name</th>
                  <th className="py-3.5 px-4">Personal Demographics</th>
                  <th className="py-3.5 px-4">Disease / Diagnosis</th>
                  <th className="py-3.5 px-4">Prescribed Medications</th>
                  <th className="py-3.5 px-4">DSA Match / Distance</th>
                  <th className="py-3.5 px-4">Care Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {paginatedResults.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-500 font-mono">
                      <p className="text-sm">No patients found matching &quot;{searchQuery}&quot;</p>
                      <p className="text-xs mt-1 text-slate-600">
                        Try clearing search or filters to browse all 1,000 records
                      </p>
                    </td>
                  </tr>
                ) : (
                  paginatedResults.map(({ patient, matchedField, matchedValue, distance, similarity, exactMatch, correctedTerm }) => (
                    <tr
                      key={patient.id}
                      className="hover:bg-slate-800/40 transition group cursor-pointer"
                      onClick={() => setSelectedPatient(patient)}
                    >
                      {/* Patient ID & Name */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-slate-800 group-hover:bg-amber-400 group-hover:text-slate-950 text-amber-300 font-bold text-xs flex items-center justify-center transition">
                            {patient.name.charAt(0)}
                          </div>
                          <div>
                            <div className="font-bold text-white group-hover:text-amber-300 transition">
                              {patient.name}
                            </div>
                            <div className="text-[10px] text-slate-500 font-mono">
                              {patient.id}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Demographics */}
                      <td className="py-3.5 px-4 text-slate-300">
                        <div>
                          {patient.age} yrs, {patient.gender}
                        </div>
                        <div className="text-[10px] text-rose-400">
                          Blood: {patient.bloodGroup} • {patient.contact}
                        </div>
                      </td>

                      {/* Diagnosis & Ward */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-200 truncate max-w-[200px]">
                          {patient.diagnosis}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate max-w-[200px]">
                          {patient.department} • {patient.attendingPhysician.split(',')[0]}
                        </div>
                      </td>

                      {/* Prescribed Medications */}
                      <td className="py-3.5 px-4">
                        <div className="flex flex-wrap gap-1 max-w-[240px]">
                          {patient.medications.map((m, idx) => (
                            <span
                              key={idx}
                              className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-950 border border-slate-800 text-[10px] text-amber-300"
                            >
                              <Pill className="w-2.5 h-2.5 text-amber-400" />
                              <span>{m.drugName} ({m.dosage})</span>
                            </span>
                          ))}
                        </div>
                      </td>

                      {/* Match & Levenshtein Metrics */}
                      <td className="py-3.5 px-4">
                        {searchQuery ? (
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span
                                className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                  exactMatch
                                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                }`}
                              >
                                {exactMatch ? 'Exact' : `Dist: ${distance}`}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">
                                {similarity}% match
                              </span>
                            </div>
                            {correctedTerm && (
                              <div className="text-[10px] text-amber-300 mt-0.5">
                                Corrected: {correctedTerm}
                              </div>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-600 text-[11px]">—</span>
                        )}
                      </td>

                      {/* Care Status */}
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusBadge(
                            patient.status
                          )}`}
                        >
                          {patient.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right space-x-1" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => setSelectedPatient(patient)}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] transition cursor-pointer"
                        >
                          Details
                        </button>

                        <button
                          type="button"
                          onClick={() => onInspectDP(searchQuery || 'dibetes', patient.diagnosis)}
                          className="px-2 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] transition cursor-pointer"
                          title="Trace Levenshtein Dynamic Programming Matrix"
                        >
                          DP Trace
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Pagination Bar */}
      {totalPages > 1 && (
        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 font-mono text-xs">
          <div className="text-slate-400">
            Showing page <strong className="text-white">{currentPage}</strong> of{' '}
            <strong className="text-white">{totalPages}</strong> ({results.length} patients loaded)
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => handlePageChange(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-white cursor-pointer"
              title="Previous Page"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            {/* Page Number Buttons */}
            <div className="flex items-center gap-1">
              {Array.from({ length: Math.min(5, totalPages) }).map((_, idx) => {
                let pageNum: number;
                if (totalPages <= 5) {
                  pageNum = idx + 1;
                } else if (currentPage <= 3) {
                  pageNum = idx + 1;
                } else if (currentPage >= totalPages - 2) {
                  pageNum = totalPages - 4 + idx;
                } else {
                  pageNum = currentPage - 2 + idx;
                }

                return (
                  <button
                    key={pageNum}
                    type="button"
                    onClick={() => handlePageChange(pageNum)}
                    className={`w-8 h-8 rounded-lg text-xs font-bold transition cursor-pointer ${
                      currentPage === pageNum
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                    }`}
                  >
                    {pageNum}
                  </button>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-white cursor-pointer"
              title="Next Page"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Add Patient Modal */}
      <AddPatientModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddPatient={(newPatient) => {
          onAddPatient(newPatient);
          setSelectedPatient(newPatient);
        }}
        nextId={nextPatientId}
      />

      {/* Patient Details Modal */}
      <PatientDetailsModal
        patient={selectedPatient}
        onClose={() => setSelectedPatient(null)}
        onInspectDP={(q, target) => onInspectDP(q, target)}
        currentQuery={searchQuery}
      />
    </div>
  );
}
