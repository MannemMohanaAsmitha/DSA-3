export type MedicalCategory = 'drug' | 'symptom' | 'diagnosis';

export interface MedicalEntry {
  id: string;
  term: string;
  category: MedicalCategory;
  categoryLabel: string;
  definition: string;
  indications: string;
  clinicalNotes: string;
  commonMisspellings: string[];
}

export interface SearchResult {
  entry: MedicalEntry;
  distance: number;
  similarity: number; // 0 - 100%
  exactMatch: boolean;
  prefixMatch: boolean;
  operations: {
    insertions: number;
    deletions: number;
    substitutions: number;
  };
}

export interface DPMatrixResult {
  s1: string;
  s2: string;
  matrix: number[][];
  optimalPath: [number, number][];
  distance: number;
  steps: {
    stepIndex: number;
    i: number;
    j: number;
    char1: string;
    char2: string;
    operation: 'match' | 'insert' | 'delete' | 'substitute';
    cost: number;
    explanation: string;
  }[];
}

export interface BenchmarkTestCase {
  id: string;
  misspelledQuery: string;
  targetTerm: string;
  category: MedicalCategory;
  errorType: 'Substitution' | 'Omission' | 'Insertion' | 'Transposition' | 'Phonetic/Complex';
  expectedDistance: number;
}

export interface TeamMember {
  name: string;
  rollNo: string;
  initials: string;
  role: string;
  department: string;
}

export interface PatientMedication {
  drugName: string;
  dosage: string;
  frequency: string;
}

export interface Patient {
  id: string; // e.g. "PID-1042"
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  bloodGroup: string;
  contact: string;
  admissionDate: string;
  diagnosis: string;
  symptoms: string[];
  medications: PatientMedication[];
  attendingPhysician: string;
  department: string;
  status: 'Inpatient' | 'Outpatient' | 'Discharged' | 'Critical';
  notes: string;
}

export interface PatientSearchResult {
  patient: Patient;
  matchedField: 'name' | 'id' | 'diagnosis' | 'symptoms' | 'medications';
  matchedValue: string;
  distance: number;
  similarity: number;
  exactMatch: boolean;
  correctedTerm?: string;
  errorType?: string;
}

