import { MedicalEntry, SearchResult, DPMatrixResult } from '../types/index.ts';

/**
 * Calculates standard Levenshtein Distance using Dynamic Programming
 * Recurrence:
 * D[i, j] = min(
 *   D[i-1, j] + 1,       // Deletion
 *   D[i, j-1] + 1,       // Insertion
 *   D[i-1, j-1] + cost   // Match (0) or Substitution (1)
 * )
 */
export function computeLevenshteinDistance(s1: string, s2: string): number {
  const a = s1.toLowerCase().trim();
  const b = s2.toLowerCase().trim();

  const m = a.length;
  const n = b.length;

  if (m === 0) return n;
  if (n === 0) return m;

  let prevRow = new Array<number>(n + 1);
  let currRow = new Array<number>(n + 1);

  for (let j = 0; j <= n; j++) {
    prevRow[j] = j;
  }

  for (let i = 1; i <= m; i++) {
    currRow[0] = i;
    const charA = a[i - 1];

    for (let j = 1; j <= n; j++) {
      const charB = b[j - 1];
      const cost = charA === charB ? 0 : 1;

      currRow[j] = Math.min(
        prevRow[j] + 1,      // deletion from a
        currRow[j - 1] + 1,  // insertion to a
        prevRow[j - 1] + cost // substitution or match
      );
    }

    // Swap rows
    const temp = prevRow;
    prevRow = currRow;
    currRow = temp;
  }

  return prevRow[n];
}

/**
 * Detailed 2D Dynamic Programming matrix computation with backtracking.
 * Useful for visual exploration and academic demonstration of the algorithm.
 */
export function computeDetailedDPMatrix(s1: string, s2: string): DPMatrixResult {
  const str1 = s1.trim();
  const str2 = s2.trim();
  const lower1 = str1.toLowerCase();
  const lower2 = str2.toLowerCase();

  const m = lower1.length;
  const n = lower2.length;

  const matrix: number[][] = Array.from({ length: m + 1 }, () => new Array<number>(n + 1).fill(0));

  // Initialize base cases
  for (let i = 0; i <= m; i++) {
    matrix[i][0] = i;
  }
  for (let j = 0; j <= n; j++) {
    matrix[0][j] = j;
  }

  // Fill DP Table
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = lower1[i - 1] === lower2[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,      // Deletion
        matrix[i][j - 1] + 1,      // Insertion
        matrix[i - 1][j - 1] + cost // Substitution / Match
      );
    }
  }

  // Backtracking to find optimal alignment path
  const optimalPath: [number, number][] = [];
  let currI = m;
  let currJ = n;
  optimalPath.push([currI, currJ]);

  const rawSteps: {
    i: number;
    j: number;
    char1: string;
    char2: string;
    operation: 'match' | 'insert' | 'delete' | 'substitute';
    cost: number;
    explanation: string;
  }[] = [];

  while (currI > 0 || currJ > 0) {
    if (currI > 0 && currJ > 0) {
      const isMatch = lower1[currI - 1] === lower2[currJ - 1];
      const matchSubCost = isMatch ? 0 : 1;

      // Check diagonal (Match / Substitute)
      if (matrix[currI][currJ] === matrix[currI - 1][currJ - 1] + matchSubCost) {
        rawSteps.push({
          i: currI,
          j: currJ,
          char1: str1[currI - 1],
          char2: str2[currJ - 1],
          operation: isMatch ? 'match' : 'substitute',
          cost: matchSubCost,
          explanation: isMatch
            ? `Characters '${str1[currI - 1]}' and '${str2[currJ - 1]}' match (Cost 0).`
            : `Substitute '${str1[currI - 1]}' with '${str2[currJ - 1]}' (Cost 1).`
        });
        currI--;
        currJ--;
        optimalPath.push([currI, currJ]);
        continue;
      }
    }

    // Check deletion (Move up)
    if (currI > 0 && matrix[currI][currJ] === matrix[currI - 1][currJ] + 1) {
      rawSteps.push({
        i: currI,
        j: currJ,
        char1: str1[currI - 1],
        char2: '—',
        operation: 'delete',
        cost: 1,
        explanation: `Delete '${str1[currI - 1]}' from query (Cost 1).`
      });
      currI--;
      optimalPath.push([currI, currJ]);
      continue;
    }

    // Check insertion (Move left)
    if (currJ > 0 && matrix[currI][currJ] === matrix[currI][currJ - 1] + 1) {
      rawSteps.push({
        i: currI,
        j: currJ,
        char1: '—',
        char2: str2[currJ - 1],
        operation: 'insert',
        cost: 1,
        explanation: `Insert '${str2[currJ - 1]}' to match target (Cost 1).`
      });
      currJ--;
      optimalPath.push([currI, currJ]);
      continue;
    }

    break;
  }

  // Path is from (m,n) down to (0,0), so reverse it for display
  optimalPath.reverse();
  const steps = rawSteps.reverse().map((step, idx) => ({
    ...step,
    stepIndex: idx + 1
  }));

  return {
    s1: str1,
    s2: str2,
    matrix,
    optimalPath,
    distance: matrix[m][n],
    steps
  };
}

/**
 * Searches the curated Medical Corpus using the Minimum Edit Distance Algorithm
 */
export function searchMedicalCorpus(
  query: string,
  corpus: MedicalEntry[],
  options: {
    maxDistance?: number;
    category?: string;
  } = {}
): SearchResult[] {
  const cleanQuery = query.trim().toLowerCase();
  if (!cleanQuery) return [];

  const maxDist = options.maxDistance ?? 4;
  const filtered = options.category && options.category !== 'all'
    ? corpus.filter((c) => c.category === options.category)
    : corpus;

  const results: SearchResult[] = [];

  for (const entry of filtered) {
    const termLower = entry.term.toLowerCase();
    const words = termLower.split(/\s+/);

    // Calculate distance to full term and individual words
    const fullDist = computeLevenshteinDistance(cleanQuery, termLower);
    
    // Also check distance to individual words (e.g. "dibetes" in "Diabetes Mellitus")
    let bestWordDist = fullDist;
    for (const w of words) {
      const wDist = computeLevenshteinDistance(cleanQuery, w);
      if (wDist < bestWordDist) {
        bestWordDist = wDist;
      }
    }

    // Check if query is an exact alias or misspelling in our list
    const hasKnownMisspelling = entry.commonMisspellings.some(
      (m) => m.toLowerCase() === cleanQuery
    );

    const minDistance = Math.min(fullDist, bestWordDist);
    const effectiveDistance = hasKnownMisspelling ? Math.min(minDistance, 1) : minDistance;

    const maxLength = Math.max(cleanQuery.length, termLower.length);
    const rawSimilarity = Math.max(0, 1 - effectiveDistance / maxLength);
    const similarityPercent = Math.round(rawSimilarity * 100);

    const isExact = termLower === cleanQuery || words.some((w) => w === cleanQuery);
    const isPrefix = termLower.startsWith(cleanQuery) || words.some((w) => w.startsWith(cleanQuery));

    // Dynamic threshold: for short queries (<=4 chars), be strict; for longer queries allow maxDist
    const allowedDist = cleanQuery.length <= 3 ? 1 : cleanQuery.length <= 5 ? 2 : maxDist;

    if (effectiveDistance <= allowedDist || isPrefix || isExact || hasKnownMisspelling) {
      // Rough estimate of operations
      const lenDiff = Math.abs(cleanQuery.length - termLower.length);
      const subs = Math.max(0, effectiveDistance - lenDiff);
      const ins = cleanQuery.length < termLower.length ? lenDiff : 0;
      const dels = cleanQuery.length > termLower.length ? lenDiff : 0;

      results.push({
        entry,
        distance: effectiveDistance,
        similarity: isExact ? 100 : similarityPercent,
        exactMatch: isExact,
        prefixMatch: isPrefix,
        operations: {
          insertions: ins,
          deletions: dels,
          substitutions: subs
        }
      });
    }
  }

  // Sort by:
  // 1. Exact match first
  // 2. Lowest edit distance
  // 3. Highest similarity percentage
  // 4. Prefix match
  results.sort((a, b) => {
    if (a.exactMatch && !b.exactMatch) return -1;
    if (!a.exactMatch && b.exactMatch) return 1;
    if (a.distance !== b.distance) return a.distance - b.distance;
    if (b.similarity !== a.similarity) return b.similarity - a.similarity;
    if (a.prefixMatch && !b.prefixMatch) return -1;
    if (!a.prefixMatch && b.prefixMatch) return 1;
    return a.entry.term.localeCompare(b.entry.term);
  });

  return results;
}

/**
 * Traditional exact match search (simulates legacy database WHERE term = ?)
 */
export function runExactSearch(query: string, corpus: MedicalEntry[]): MedicalEntry[] {
  const clean = query.trim().toLowerCase();
  if (!clean) return [];

  return corpus.filter((entry) => {
    const termLower = entry.term.toLowerCase();
    const words = termLower.split(/\s+/);
    return termLower === clean || words.some((w) => w === clean);
  });
}
