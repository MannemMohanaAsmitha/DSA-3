import { MEDICAL_CORPUS } from '../data/medicalCorpus.ts';
import { computeLevenshteinDistance } from './levenshtein.ts';
import { MedicalEntry } from '../types/index.ts';

export interface SpellingMistakeDetection {
  originalQuery: string;
  correctedTerm: string;
  category: 'diagnosis' | 'drug' | 'symptom';
  categoryLabel: string;
  editDistance: number;
  similarity: number;
  errorType: 'Omission' | 'Insertion' | 'Substitution' | 'Transposition' | 'Exact Match';
  explanation: string;
  matchedEntry: MedicalEntry;
  matchedWord?: string;
}

/**
 * Analyzes an input query against the medical corpus dictionary to detect
 * errors, classify the mistake (Omission, Insertion, Substitution, Transposition),
 * and provide the optimal medical dictionary auto-correction.
 */
export function detectAndCorrectMedicalMistake(
  rawQuery: string,
  targetCategory?: 'diagnosis' | 'drug' | 'symptom'
): SpellingMistakeDetection | null {
  const query = rawQuery.trim().toLowerCase();
  if (!query || query.length < 2) return null;

  const corpus = targetCategory
    ? MEDICAL_CORPUS.filter((c) => c.category === targetCategory)
    : MEDICAL_CORPUS;

  let bestMatch: MedicalEntry | null = null;
  let bestDistance = 999;
  let bestSimilarity = 0;
  let bestMatchedWord = '';
  let isKnownMisspelling = false;

  for (const entry of corpus) {
    const termLower = entry.term.toLowerCase();
    const words = termLower.split(/\s+/);

    // 1. Check known misspellings in corpus
    const knownIdx = entry.commonMisspellings.findIndex(
      (m) => m.toLowerCase() === query
    );
    if (knownIdx !== -1) {
      bestMatch = entry;
      bestDistance = 1;
      bestSimilarity = 95;
      bestMatchedWord = entry.term;
      isKnownMisspelling = true;
      break;
    }

    // 2. Check full term distance
    const fullDist = computeLevenshteinDistance(query, termLower);
    if (fullDist < bestDistance) {
      bestDistance = fullDist;
      bestMatch = entry;
      bestMatchedWord = entry.term;
    }

    // 3. Check individual tokens in multi-word terms (e.g. "dibetes" in "Diabetes Mellitus")
    for (const w of words) {
      const wDist = computeLevenshteinDistance(query, w);
      if (wDist < bestDistance) {
        bestDistance = wDist;
        bestMatch = entry;
        bestMatchedWord = w;
      }
    }
  }

  if (!bestMatch) return null;

  const targetLower = (bestMatchedWord || bestMatch.term).toLowerCase();
  const maxLen = Math.max(query.length, targetLower.length);
  bestSimilarity = Math.max(10, Math.round((1 - bestDistance / maxLen) * 100));

  // Determine if it's exact match
  if (query === targetLower || query === bestMatch.term.toLowerCase()) {
    return {
      originalQuery: rawQuery,
      correctedTerm: bestMatch.term,
      category: bestMatch.category,
      categoryLabel: bestMatch.categoryLabel,
      editDistance: 0,
      similarity: 100,
      errorType: 'Exact Match',
      explanation: `'${rawQuery}' is an exact match for '${bestMatch.term}'.`,
      matchedEntry: bestMatch,
      matchedWord: bestMatchedWord
    };
  }

  // Only report as mistake if distance is within tolerance (<= 3 edits or <= 50% length)
  const allowedDistance = query.length <= 4 ? 1 : query.length <= 7 ? 2 : 3;
  if (bestDistance > allowedDistance && !isKnownMisspelling) {
    return null;
  }

  // Classify Error Type
  let errorType: SpellingMistakeDetection['errorType'] = 'Substitution';
  let explanation = '';

  const lenDiff = query.length - targetLower.length;
  if (lenDiff < 0) {
    errorType = 'Omission';
    const missingChars = Math.abs(lenDiff);
    explanation = `Omission error: User omitted ${missingChars} character${missingChars > 1 ? 's' : ''} from '${bestMatch.term}'.`;
  } else if (lenDiff > 0) {
    errorType = 'Insertion';
    explanation = `Insertion error: Extra ${lenDiff} character${lenDiff > 1 ? 's' : ''} entered beyond '${bestMatch.term}'.`;
  } else {
    // Same length: test transposition vs substitution
    let diffCount = 0;
    for (let i = 0; i < query.length; i++) {
      if (query[i] !== targetLower[i]) diffCount++;
    }
    if (diffCount === 2) {
      errorType = 'Transposition';
      explanation = `Transposition / Swapped character error in '${query}'.`;
    } else {
      errorType = 'Substitution';
      explanation = `Substitution error: Replaced ${bestDistance} character${bestDistance > 1 ? 's' : ''} in '${bestMatch.term}'.`;
    }
  }

  return {
    originalQuery: rawQuery,
    correctedTerm: bestMatch.term,
    category: bestMatch.category,
    categoryLabel: bestMatch.categoryLabel,
    editDistance: bestDistance,
    similarity: bestSimilarity,
    errorType,
    explanation,
    matchedEntry: bestMatch,
    matchedWord: bestMatchedWord
  };
}

export interface AutoCorrectionResult {
  original: string;
  corrected: string;
  wasCorrected: boolean;
  details: SpellingMistakeDetection | null;
}

/**
 * Automatically detects and corrects misspelled diagnosis terms using the DSA Levenshtein dictionary
 */
export function autoCorrectDiagnosis(input: string): AutoCorrectionResult {
  const trimmed = input.trim();
  if (!trimmed || trimmed.length < 3) {
    return { original: input, corrected: input, wasCorrected: false, details: null };
  }
  const mistake = detectAndCorrectMedicalMistake(trimmed, 'diagnosis');
  if (mistake && mistake.editDistance > 0) {
    return {
      original: input,
      corrected: mistake.correctedTerm,
      wasCorrected: true,
      details: mistake
    };
  }
  return { original: input, corrected: input, wasCorrected: false, details: null };
}

/**
 * Automatically detects and corrects misspelled medication names using the DSA Levenshtein dictionary
 */
export function autoCorrectMedication(drugName: string): AutoCorrectionResult {
  const trimmed = drugName.trim();
  if (!trimmed || trimmed.length < 3) {
    return { original: drugName, corrected: drugName, wasCorrected: false, details: null };
  }
  const mistake = detectAndCorrectMedicalMistake(trimmed, 'drug');
  if (mistake && mistake.editDistance > 0) {
    return {
      original: drugName,
      corrected: mistake.correctedTerm,
      wasCorrected: true,
      details: mistake
    };
  }
  return { original: drugName, corrected: drugName, wasCorrected: false, details: null };
}

/**
 * Automatically detects and corrects misspelled symptom items in a comma-separated list
 */
export function autoCorrectSymptoms(symptomsInput: string): {
  corrected: string;
  correctedCount: number;
  corrections: { from: string; to: string }[];
} {
  const parts = symptomsInput.split(',').map((s) => s.trim());
  const corrections: { from: string; to: string }[] = [];
  const correctedParts = parts.map((part) => {
    if (!part || part.length < 3) return part;
    const mistake = detectAndCorrectMedicalMistake(part, 'symptom');
    if (mistake && mistake.editDistance > 0) {
      corrections.push({ from: part, to: mistake.correctedTerm });
      return mistake.correctedTerm;
    }
    return part;
  });

  return {
    corrected: correctedParts.join(', '),
    correctedCount: corrections.length,
    corrections
  };
}

/**
 * Automatically detects and corrects misspelled query strings across all medical categories
 */
export function autoCorrectSearchQuery(query: string): AutoCorrectionResult {
  const trimmed = query.trim();
  if (!trimmed || trimmed.length < 2) {
    return { original: query, corrected: query, wasCorrected: false, details: null };
  }
  const mistake = detectAndCorrectMedicalMistake(trimmed);
  if (mistake && mistake.editDistance > 0) {
    return {
      original: query,
      corrected: mistake.correctedTerm,
      wasCorrected: true,
      details: mistake
    };
  }
  return { original: query, corrected: query, wasCorrected: false, details: null };
}
