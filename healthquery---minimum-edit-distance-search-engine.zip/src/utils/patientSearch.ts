import { Patient, PatientSearchResult } from '../types/index.ts';
import { computeLevenshteinDistance } from './levenshtein.ts';
import { detectAndCorrectMedicalMistake, SpellingMistakeDetection } from './spellingCorrection.ts';

export interface PatientSearchOptions {
  maxDistance?: number;
  departmentFilter?: string;
  statusFilter?: string;
}

export interface PatientSearchResponse {
  results: PatientSearchResult[];
  latencyMs: number;
  scannedCount: number;
  detectedMistake: SpellingMistakeDetection | null;
}

/**
 * Searches the 1,000 patient records using Levenshtein Dynamic Programming & multi-field matching
 * with integrated Dictionary Error/Mistake Detection and Auto-Correction.
 */
export function searchPatients(
  query: string,
  patients: Patient[],
  options: PatientSearchOptions = {}
): PatientSearchResponse {
  const startTime = performance.now();
  const cleanQuery = query.trim().toLowerCase();

  const maxDist = options.maxDistance ?? 2;
  const deptFilter = options.departmentFilter && options.departmentFilter !== 'all' ? options.departmentFilter : null;
  const statusFilter = options.statusFilter && options.statusFilter !== 'all' ? options.statusFilter : null;

  // Filter by department and status first if specified
  const filteredPatients = patients.filter((p) => {
    if (deptFilter && p.department !== deptFilter) return false;
    if (statusFilter && p.status !== statusFilter) return false;
    return true;
  });

  if (!cleanQuery) {
    // If no query, return complete filtered list with zero distance
    const results: PatientSearchResult[] = filteredPatients.map((p) => ({
      patient: p,
      matchedField: 'name',
      matchedValue: p.name,
      distance: 0,
      similarity: 100,
      exactMatch: true
    }));

    const endTime = performance.now();
    return {
      results,
      latencyMs: +(endTime - startTime).toFixed(2),
      scannedCount: filteredPatients.length,
      detectedMistake: null
    };
  }

  // Detect spelling mistake against medical corpus dictionary
  const detectedMistake = detectAndCorrectMedicalMistake(cleanQuery);
  const correctedTermLower = detectedMistake ? detectedMistake.correctedTerm.toLowerCase() : '';
  const correctedWords = correctedTermLower ? correctedTermLower.split(/\s+/) : [];

  const matchedList: PatientSearchResult[] = [];

  for (const patient of filteredPatients) {
    let bestDistance = 999;
    let bestSimilarity = 0;
    let matchedField: PatientSearchResult['matchedField'] = 'name';
    let matchedValue = '';
    let isExact = false;
    let matchHasCorrection = false;

    // 1. Direct ID match (e.g. "PID-1042" or "1042")
    const idLower = patient.id.toLowerCase();
    if (idLower === cleanQuery || idLower.replace('pid-', '') === cleanQuery) {
      matchedList.push({
        patient,
        matchedField: 'id',
        matchedValue: patient.id,
        distance: 0,
        similarity: 100,
        exactMatch: true
      });
      continue;
    }

    // 2. Name checking (e.g. "Aravind Reddy", checking "aravnd")
    const nameLower = patient.name.toLowerCase();
    const nameWords = nameLower.split(/\s+/);
    
    if (nameLower === cleanQuery) {
      bestDistance = 0;
      bestSimilarity = 100;
      matchedField = 'name';
      matchedValue = patient.name;
      isExact = true;
    } else if (nameLower.includes(cleanQuery)) {
      bestDistance = 0;
      bestSimilarity = 95;
      matchedField = 'name';
      matchedValue = patient.name;
    } else {
      const distFullName = computeLevenshteinDistance(cleanQuery, nameLower);
      if (distFullName < bestDistance) {
        bestDistance = distFullName;
        matchedField = 'name';
        matchedValue = patient.name;
      }

      for (const w of nameWords) {
        const wDist = computeLevenshteinDistance(cleanQuery, w);
        if (wDist < bestDistance) {
          bestDistance = wDist;
          matchedField = 'name';
          matchedValue = patient.name;
        }
      }
    }

    // 3. Diagnosis checking (e.g. "Diabetes Mellitus", checking "dibetes")
    const diagLower = patient.diagnosis.toLowerCase();
    const diagWords = diagLower.split(/\s+/);

    // Check if patient's diagnosis matches the dictionary-corrected term
    if (correctedTermLower && (diagLower === correctedTermLower || diagWords.some((w) => correctedWords.includes(w)))) {
      const dist = detectedMistake ? detectedMistake.editDistance : 1;
      if (dist < bestDistance) {
        bestDistance = dist;
        bestSimilarity = detectedMistake ? detectedMistake.similarity : 90;
        matchedField = 'diagnosis';
        matchedValue = patient.diagnosis;
        matchHasCorrection = true;
      }
    }

    if (diagLower === cleanQuery) {
      bestDistance = 0;
      bestSimilarity = 100;
      matchedField = 'diagnosis';
      matchedValue = patient.diagnosis;
      isExact = true;
      matchHasCorrection = false;
    } else if (diagLower.includes(cleanQuery)) {
      if (bestDistance > 0) {
        bestDistance = 0;
        bestSimilarity = 92;
        matchedField = 'diagnosis';
        matchedValue = patient.diagnosis;
      }
    } else {
      for (const dw of diagWords) {
        const dDist = computeLevenshteinDistance(cleanQuery, dw);
        if (dDist < bestDistance) {
          bestDistance = dDist;
          bestSimilarity = Math.max(10, Math.round((1 - dDist / Math.max(cleanQuery.length, dw.length)) * 100));
          matchedField = 'diagnosis';
          matchedValue = patient.diagnosis;
        }
      }
    }

    // 4. Symptoms checking (e.g. ['Dyspnea', 'Headache'], checking "dispnea" or "headach")
    for (const sym of patient.symptoms) {
      const symLower = sym.toLowerCase();

      if (correctedTermLower && symLower === correctedTermLower) {
        const dist = detectedMistake ? detectedMistake.editDistance : 1;
        if (dist < bestDistance) {
          bestDistance = dist;
          bestSimilarity = detectedMistake ? detectedMistake.similarity : 90;
          matchedField = 'symptoms';
          matchedValue = sym;
          matchHasCorrection = true;
        }
      }

      if (symLower === cleanQuery) {
        bestDistance = 0;
        bestSimilarity = 100;
        matchedField = 'symptoms';
        matchedValue = sym;
        isExact = true;
        matchHasCorrection = false;
        break;
      } else if (symLower.includes(cleanQuery)) {
        if (bestDistance > 0) {
          bestDistance = 0;
          bestSimilarity = 90;
          matchedField = 'symptoms';
          matchedValue = sym;
        }
      } else {
        const sDist = computeLevenshteinDistance(cleanQuery, symLower);
        if (sDist < bestDistance) {
          bestDistance = sDist;
          bestSimilarity = Math.max(10, Math.round((1 - sDist / Math.max(cleanQuery.length, symLower.length)) * 100));
          matchedField = 'symptoms';
          matchedValue = sym;
        }
      }
    }

    // 5. Medications checking (e.g. 'Paracetamol', 'Metformin')
    for (const med of patient.medications) {
      const medLower = med.drugName.toLowerCase();

      if (correctedTermLower && medLower === correctedTermLower) {
        const dist = detectedMistake ? detectedMistake.editDistance : 1;
        if (dist < bestDistance) {
          bestDistance = dist;
          bestSimilarity = detectedMistake ? detectedMistake.similarity : 90;
          matchedField = 'medications';
          matchedValue = `${med.drugName} (${med.dosage})`;
          matchHasCorrection = true;
        }
      }

      if (medLower === cleanQuery) {
        bestDistance = 0;
        bestSimilarity = 100;
        matchedField = 'medications';
        matchedValue = `${med.drugName} (${med.dosage})`;
        isExact = true;
        matchHasCorrection = false;
        break;
      } else if (medLower.includes(cleanQuery)) {
        if (bestDistance > 0) {
          bestDistance = 0;
          bestSimilarity = 90;
          matchedField = 'medications';
          matchedValue = `${med.drugName} (${med.dosage})`;
        }
      } else {
        const mDist = computeLevenshteinDistance(cleanQuery, medLower);
        if (mDist < bestDistance) {
          bestDistance = mDist;
          bestSimilarity = Math.max(10, Math.round((1 - mDist / Math.max(cleanQuery.length, medLower.length)) * 100));
          matchedField = 'medications';
          matchedValue = `${med.drugName} (${med.dosage})`;
        }
      }
    }

    // Threshold check: allow if edit distance is within tolerance or if auto-corrected
    const allowedDist = cleanQuery.length <= 3 ? 1 : cleanQuery.length <= 5 ? 2 : maxDist;

    if (bestDistance <= allowedDist || isExact || matchHasCorrection || bestSimilarity >= 75) {
      if (bestSimilarity === 0) {
        const maxLen = Math.max(cleanQuery.length, matchedValue.length || 6);
        bestSimilarity = Math.max(10, Math.round((1 - bestDistance / maxLen) * 100));
      }

      matchedList.push({
        patient,
        matchedField,
        matchedValue,
        distance: bestDistance,
        similarity: bestSimilarity,
        exactMatch: isExact,
        correctedTerm: matchHasCorrection && detectedMistake ? detectedMistake.correctedTerm : undefined,
        errorType: matchHasCorrection && detectedMistake ? detectedMistake.errorType : undefined
      });
    }
  }

  // Sort matched results:
  // 1. Exact match first
  // 2. Minimum edit distance ascending
  // 3. Similarity percentage descending
  // 4. Patient ID ascending
  matchedList.sort((a, b) => {
    if (a.exactMatch && !b.exactMatch) return -1;
    if (!a.exactMatch && b.exactMatch) return 1;
    if (a.distance !== b.distance) return a.distance - b.distance;
    if (b.similarity !== a.similarity) return b.similarity - a.similarity;
    return a.patient.id.localeCompare(b.patient.id);
  });

  const endTime = performance.now();
  return {
    results: matchedList,
    latencyMs: +(endTime - startTime).toFixed(2),
    scannedCount: filteredPatients.length,
    detectedMistake: detectedMistake && detectedMistake.editDistance > 0 ? detectedMistake : null
  };
}
